var contentStates=[];
$(document).ready(function() {

function pushState()
{
	 contentStates.push($("#body-content").html())
	 console.log("content pushed.."+contentStates.length);
}

 $(document).on('click','.transitionLink',function()
 {
	pushState();
 }
 );
 var seats
 user_id=localStorage.getItem("user_id");
 user_name=localStorage.getItem("user_name");
 
 if(user_id==null)
 {
	 alert("Please Login");
	 window.location.href = "index.html";
	 
 }

$('#welcome-text').text("Welcome "+user_name);

$(document).on('click','.buses-link',function(event){
	event.preventDefault();
	$('#owner-menu').hide();
	$('#add-bus-div').show();
	$('#buses-div').show();
	getBuses(localStorage.getItem("user_id"));
	$('.add-bus-sleeper').hide();
});

$(document).on('change','input[name="type"]',function () {
    var selectedType = $('input[name="type"]:checked').val();
    if(selectedType=="SEATER")
    {
		$('.add-bus-seater').show();
		$('.add-bus-sleeper').hide();
		$('#add-bus-sleeper-rows').val(0);
		
	}
	else if(selectedType=="SLEEPER")
    {
		$('.add-bus-seater').hide();
		$('.add-bus-sleeper').show();
		$('#add-bus-seater-rows').val(0);
		
	}
});

$(document).on('submit','#add-bus-form',function(event){
	event.preventDefault();
	var type = $('input[name="type"]:checked').val();
	if(type=="SEATER" && parseInt($('#add-bus-seater-rows').val())<1)
	{
		alert("Enter valid Seater row count");
		return;
	}
	else if(type=="SLEEPER" && parseInt($('#add-bus-sleeper-rows').val())<1)
	{
		alert("Enter valid Upper/Lower row count");
		return;
	}
	
	
	        var formData = $('#add-bus-form').serializeArray();
            var json = {};

            $.each(formData, function () {
                json[this.name] = this.value;
            });
            json["ownerId"]=localStorage.getItem("user_id");
            console.log(JSON.stringify(json));
            $.ajax({
			url:'./bus',
			type:'POST',
			contentType:"application/json",
			data:JSON.stringify(json),
			success:function(res)
			{
				if(res.success)
				{
					alert(res.success);
					object=res.bus;
					var table=$("#buses-table");
					var i=$("#buses-table tr").length;
					var row=getBusRow(i,object);
					
		            table.append(row);
					clearForm("#add-bus-form");
					//getBuses(localStorage.getItem("user_id"));
				}
				else if(res.error)
				{
					alert(res.error);
					return;
				}
			},
			error:function(error)
			{
			   console.log(error);
			   alert(error);
			}
		})      
});

function getBusRow(i,object)
{
	var row = $("<tr>");
    row.append($("<td>").text(i));
    row.append($("<td>").text(object.busName));
    row.append($("<td>").text(object.busNumber));
    row.append($("<td>").text(object.type));
    row.append($("<td>").text(object.ac==1?"Yes":"No"));
    row.append($("<td>").text(object.capacity));
    
    var scheduleButton = $('<button>')
    .attr("bus",JSON.stringify(object))
    .attr("href","javascript:void(0)")
    .attr("class","tripScheduleLink transitionLink")
    .text('Trip Schesule');
	row.append($('<td>').append(scheduleButton));
	
	var tripsButton = $('<button>')
    .attr("bus",JSON.stringify(object))
    .attr("href","javascript:void(0)")
    .attr("class","tripsLink transitionLink")
    .text('Trips');
	row.append($('<td>').append(tripsButton));
    
    var editButton = $('<button>')
    .attr("bus",JSON.stringify(object))
    .attr("href","javascript:void(0)")
    .attr("class","busEditLink")
    .text('Edit');
	row.append($('<td>').append(editButton));
	
  	var deleteButton = $('<button>')
  	.attr("bus",JSON.stringify(object))
  	.attr("href","javascript:void(0)")
    .attr("class","busDeleteLink")
    .text('Delete');
    
    row.append($('<td>').append(deleteButton));
    return row;
}


function clearForm(formId)
{
	$(formId+' input[type="text"]').val('');
	$(formId+' input[type="number"]').val('0');
	$(formId+' input[type="date"]').val('');
	$(formId+' input[type="time"]').val('');
}
function getBuses(userId) {
    $.ajax({
      url: './bus?userId='+userId,
      type: 'GET',
      success: function(data) {
       
  		console.log(data);
  		 let i=1;
  		 var table=$("#buses-table");
		 table.find("tr:not(:first)").remove();
  		 $.each(data, function(index, object) {
			    
			    var row = getBusRow(i,object);
		                table.append(row);
	   					i++;
		 });
      }
    });
  }
  
$(document).on('click','.tripScheduleLink',function(event) {
	event.preventDefault();
	$('#add-bus-div').hide();
	$('#buses-div').hide();
	$('#add-schedule-div').show();
	$('#schedules-div').show();
	
	
	
	var bus=JSON.parse($(this).attr("bus"));
	localStorage.setItem('bus_id',bus.busId);
	
	if(bus.type=="SEATER"){
	$('.add-schedule-sleeper').hide();
	$('.add-schedule-seater').show();
	$('#add-schedule-seater-prize').attr('min',100);
	}
	else if(bus.type=="SLEEPER"){
	$('.add-schedule-sleeper').show();
	$('.add-schedule-seater').hide();
	$('#add-schedule-upper-sleeper-prize').attr('min',100);
	$('#add-schedule-lower-sleeper-prize').attr('min',100);
	}
	
	var now=new Date();
	var today = now.toISOString().split('T')[0];
	$('#add-schedule-start-date').attr('min',today);
	$('#add-schedule-end-date').attr('min',today);
	
	getSchedules(bus.busId);   
	  
 });
 
 $('#add-schedule-start-date').on('change',function()
 	{
		now=new Date();
		start_date=$('#add-schedule-start-date').val();
		$('#add-schedule-end-date').attr('min',start_date);
		//alert(start_date);//2023-05-20
		// If start date is today, use current time as start time
		if (new Date(start_date).toDateString() === now.toDateString()) //Wed Mar 13 2002
		{
	      	var currentHours =now.getHours();
	      	var currentMinutes = now.getMinutes();
	        var minStartTime = ("0"+currentHours).slice(-2) + ':' + ("0"+currentMinutes).slice(-2);
	       $('#add-schedule-start-time').attr('min',minStartTime);
    	}
    	else
    	{
			$('#start-time').attr('min','00:00');
        }	
});
 
 $(document).on('submit','#add-schedule-form',function(event){
	 event.preventDefault();
	 var from=$('#add-schedule-from').val();
	 var to=$("#add-schedule-to").val();
	 if(from==to)
	 {
		 alert("From and To should not be the same..");
		 return;
	 }
	 var formData = $('#add-schedule-form').serializeArray();
     var json = {};

            $.each(formData, function () {
                json[this.name] = this.value;
            });
            json["busId"]=localStorage.getItem("bus_id");
            console.log(JSON.stringify(json));
            $.ajax({
			url:'./schedule',
			type:'POST',
			contentType:"application/json",
			data:JSON.stringify(json),
			success:function(res)
			{
				if(res.success)
				{
					alert(res.success);
					var table=$("#schedules-table");
					var i=$("#schedules-table tr").length;
		            table.append(getScheduleRow(i,res.schedule));
					clearForm("#add-schedule-form");
					
				}
				else if(res.error)
				{
					alert(res.error);
					return;
				}
			},
			error:function(error)
			{
			   console.log(error);
			   alert(error);
			}
		})     	 
 });
 
 function getSchedules(busId) {
    $.ajax({
      url: './schedule?busId='+busId ,
      type: 'GET',
      success: function(data) {
  		 console.log(data);
  		 let i=1;
  		 var table=$("#schedules-table");
		 table.find("tr:not(:first)").remove();
  		 $.each(data, function(index, object) {
			    table.append(getScheduleRow(i,object));
	   			i++;
		 });
      },
      error:function(error)
      {
		  console.log(error);
		  alert(error);
	  }
    });
  }
  
  function getScheduleRow(i,object)
  {
	var row = $("<tr>");
    row.append($("<td>").text(i));
    row.append($("<td>").text(object.from));
    row.append($("<td>").text(object.to));
    row.append($("<td>").text(object.startTime));
    row.append($("<td>").text(object.duration));
    row.append($("<td>").text(object.startDate));
    row.append($("<td>").text(object.endDate));
    row.append($("<td>").text(object.seaterPrize));
    row.append($("<td>").text(object.upperSleeperPrize));
    row.append($("<td>").text(object.lowerSleeperPrize));
    row.append($("<td>").text(object.isActive==1?"Active":"InActive"));
    
      
    var editButton = $('<button>')
    .attr("schedule",JSON.stringify(object))
    .attr("href","javascript:void(0)")
    .attr("class","scheduleEditLink")
    .text('Edit');
	row.append($('<td>').append(editButton));
	
  	var deleteButton = $('<button>')
  	.attr("schedule",JSON.stringify(object))
  	.attr("href","javascript:void(0)")
    .attr("class","scheduleDeleteLink")
    .text('Delete');
    
    row.append($('<td>').append(deleteButton));
    return row;
  }
  
  
  function getTrips(busId) {
    $.ajax({
      url: './trip?busId='+busId ,
      type: 'GET',
      success: function(data) {
  		 console.log(data);
  		 let i=1;
  		 var table=$("#upcoming-bus-trips-table");
		 table.find("tr:not(:first)").remove();
  		 $.each(data, function(index, object) {
			    
			    var row = $("<tr>");
		                row.append($("<td>").text('#'));
		                row.append($("<td>").text(object.tripDate));
		                row.append($("<td>").text(object.from));
		                row.append($("<td>").text(object.to));
		                row.append($("<td>").text(object.startTime));
		                row.append($("<td>").text(object.endTime));
		                row.append($("<td>").text(object.seaterPrize));
		                row.append($("<td>").text(object.upperSleeperPrize));
		                row.append($("<td>").text(object.lowerSleeperPrize));
		                row.append($("<td>").text(object.status));
		                
		                var viewTicketsButton = $('<button>')
		                .attr("trip",JSON.stringify(object))
		                .attr("href","javascript:void(0)")
		                .attr("class","viewBusTripTickets transitionLink")
			            .text('View Tickets');
			  			row.append($('<td>').append(viewTicketsButton));
		                
		                var dateTimeString = object.tripDate+"T"+object.startTime; 
                        var dateTime = new Date(dateTimeString);
						var currentDate = new Date();
						if (dateTime < currentDate || object.status!='Booking Opened') {
						    
						    $("#trips-history-table").append(row);
						    
						}else{
					                  
		                var editButton = $('<button>')
		                .attr("trip",JSON.stringify(object))
		                .attr("href","javascript:void(0)")
		                .attr("class","tripEditLink")
			            .text('Edit');
			  			row.append($('<td>').append(editButton));
			  			
			          	var deleteButton = $('<button>')
			          	.attr("trip",JSON.stringify(object))
			          	.attr("href","javascript:void(0)")
		                .attr("class","tripDeleteLink")
			            .text('Delete');
		                row.append($('<td>').append(deleteButton));
		                table.append(row);
	   					i++;
	   					}
		 });
      },
      error:function(error)
      {
		  console.log(error);
		  alert(error);
	  }
    });
  }
 $(document).on('click','.tripsLink',function(event) {
	event.preventDefault();
	$('#add-bus-div').hide();
	$('#buses-div').hide();
	
	$('#trips-div').show();
	
	var bus=JSON.parse($(this).attr("bus"));
	localStorage.setItem('bus_id',bus.busId);
	
	getTrips(bus.busId);   
	  
 });

$(document).on('click','.book-tickets-link',function(event){
	
	event.preventDefault();
	$('#owner-menu').hide();
	$('#show-available-buses-div').show();
	
	var now=new Date();
	var today = now.toISOString().split('T')[0];
	$('#show-available-buses-date').attr('min',today);
	$('#show-available-buses-date').val(today);
	
});

$(document).on('click','#show-available-buses-button',function(event){
	event.preventDefault();
	$('#available-buses-div').show();
    getAvailableBuses();
	
});

function getAvailableBuses() {
	var formData = $('#show-available-buses-form').serializeArray();
    var json = {};

    $.each(formData, function () {
    	json[this.name] = this.value;
    });
    
    $.ajax({
      url: './availableBuses' ,
      type: 'POST',
      contentType:"application/json",
	  data:JSON.stringify(json),
      success: function(data) {
  		 console.log(data);
  		 let i=1;
  		 var table=$("#available-buses-table");
		 table.find("tr:not(:first)").remove();
		 if(data.length==0)
		 {
			 var row = $("<tr>");
			 row.append($("<td colspan='12'>").text("No Buses Available"));
			 table.append(row);
			 return;
			 
		 }
  		 $.each(data, function(index, object) {
			    
			    var row = $("<tr>");
		                row.append($("<td>").text(i));
		                row.append($("<td>").text(object.busName));
		                row.append($("<td>").text(object.busNumber));
		                row.append($("<td>").text(object.type));
		                row.append($("<td>").text(object.ac==1?"Yes":"No"));
		                row.append($("<td>").text(object.startTime));
		                row.append($("<td>").text(object.endTime));
		                row.append($("<td>").text(object.seaterPrize==0?"-":object.seaterPrize));
		                row.append($("<td>").text(object.upperSleeperPrize==0?"-":object.upperSleeperPrize));
		                row.append($("<td>").text(object.lowerSleeperPrize==0?"-":object.lowerSleeperPrize));
		                row.append($("<td>").text(object.availableTickets));
		                
		                  
		                var bookTicketsButton = $('<button>')
		                .attr("details",JSON.stringify(object))
		                .attr("href","javascript:void(0)")
		                .attr("class","bookTicketsButton transitionLink")
			            .text('Book Tickets');
			  			row.append($('<td>').append(bookTicketsButton));
			  			   
		                table.append(row);
	   					i++;
		 });
      },
      error:function(error)
      {
		  console.log(error);
		  alert(error);
	  }
    });
  }
var selectedSeats=[];
var getAvailableSeatsPayload={};
$(document).on('click','.bookTicketsButton',function() {
	  $('#show-available-buses-div').hide();
	  $('#available-buses-div').hide(); 
	  $('#book-tickets-div').show();
	  var details=JSON.parse($(this).attr("details"));
	  var json={};
	  getAvailableSeatsPayload["scheduleId"]=details.scheduleId;
	  getAvailableSeatsPayload["tripId"]=details.tripId;
	  getAvailableSeatsPayload["busId"]=details.busId;
	  getAvailableSeatsPayload["seaterPrize"]=details.seaterPrize;
	  getAvailableSeatsPayload["upperSleeperPrize"]=details.upperSleeperPrize;
	  getAvailableSeatsPayload["lowerSleeperPrize"]=details.lowerSleeperPrize;
	  
	  localStorage.setItem("trip_id",details.tripId);
	  
	  selectedSeats=[];
	 
	  var selectDropdown = $("#seats-dropdown");
	  selectDropdown.empty();
	  $.ajax({
      url: './availableSeats' ,
      type: 'POST',
      contentType:"application/json",
	  data:JSON.stringify(getAvailableSeatsPayload),
      success: function(seats) {
  		 console.log(seats);
  		 $.each(seats, function(index, item) {
		    selectDropdown.append($('<option>', {
		        value: JSON.stringify(item),
		        text: item.seatNumber+' - '+item.type
		    }));
		});
  	  },
  	  error:function(error)
      {
		  console.log(error);
		  alert(error);
	  }
      });
 });
$(document).on('submit','#select-seats-form',function(event)
{		 
		 event.preventDefault();
		 var selectedSeat= JSON.parse($("#seats-dropdown").val());
		 console.log("selected "+selectedSeat);
		 console.log(selectedSeat)
		 var objectExists = selectedSeats.some(function(obj) {
         return obj.seatNumber === selectedSeat.seatNumber;
         });
         if (!objectExists) {
			 selectedSeat["name"]=$('#passenger-name').val();
			 selectedSeat["gender"]=$('#gender').val();
			 $('#passenger-name').val('');
			 selectedSeats.push(selectedSeat);
			 updateSelectedSeatsTable(selectedSeats);
		 }
		 else{
			 alert('SeatNumber '+selectedSeat.seatNumber+" already selected");
		 }
});

function updateSelectedSeatsTable(seats)
{
	let i=1;
  	var table=$("#selected-seats-table");
	table.find("tr:not(:first)").remove();
	var total=0;
	$.each(seats, function(index, object) {
			    var row = $("<tr>");
		                row.append($("<td>").text(i));
		                row.append($("<td>").text(object.seatNumber));
		                row.append($("<td>").text(object.type));
		                row.append($("<td>").text(object.name));
		                row.append($("<td>").text(object.gender));
		                row.append($("<td>").text(object.prize));
		                total=total+parseInt(object.prize);
		                
		                var removeSeatButton = $('<button>')
		                .attr("seat",JSON.stringify(object))
		                .attr("href","javascript:void(0)")
		                .attr("class","removeSeatButton ")
			            .text('Remove');
			  			row.append($('<td>').append(removeSeatButton));
			  			   
		                table.append(row);
	   					i++;
		 });
		 
		 var row=$("<tr>");
		 row.append($("<td colspan='5'>").text("Total amount"));
		 row.append($("<td>").text(total));
		 var confirmBookingButton = $('<button>')
		                .attr("selectedSeats",JSON.stringify(selectedSeats))
		                .attr("href","javascript:void(0)")
		                .attr("class","confirmBookingButton")
			            .text('Confirm');
			  			row.append($('<td>').append(confirmBookingButton));
		 table.append(row);
}

$(document).on('click','.confirmBookingButton',function(event)
{
	event.preventDefault();
	
	if(confirm("Are you sure want to book the selected seats?"))
	{
		var json={};
		json["userId"]=localStorage.getItem("user_id");
		json["seats"]=JSON.parse($(this).attr("selectedSeats"));
		json["tripId"]=localStorage.getItem("trip_id");
		console.log(json);
		$.ajax({
			url:'./bookTickets',
			type:'POST',
			contentType:"application/json",
			data:JSON.stringify(json),
			success:function(res)
			{
				if(res.success)
				{
					alert(res.success);
					clearForm("#select-seats-form");
					selectedSeats = [];
					updateSelectedSeatsTable(selectedSeats);
					var selectDropdown = $("#seats-dropdown");
					selectDropdown.empty();
					  $.ajax({
				      url: './availableSeats' ,
				      type: 'POST',
				      contentType:"application/json",
					  data:JSON.stringify(getAvailableSeatsPayload),
				      success: function(seats) {
				  		 console.log(seats);
				  		 $.each(seats, function(index, item) {
							
						    selectDropdown.append($('<option>', {
						        value: JSON.stringify(item),
						        text: item.seatNumber+' - '+item.type
						    }));
						});
				  	  },
				  	  error:function(error)
				      {
						  console.log(error);
						  alert(error);
					  }
				      });
					
				}
				else if(res.error)
				{
					alert(res.error);
					return;
				}
			},
			error:function(error)
			{
			   console.log(error);
			   alert(error);
			}
		})      
		
	}
	
	
	
});


$(document).on('click','.removeSeatButton',function(event)
{
	event.preventDefault();
	var seat=JSON.parse($(this).attr("seat"));
	selectedSeats = selectedSeats.filter(function(obj) {
    return obj.seatNumber !== seat.seatNumber;
	});
	updateSelectedSeatsTable(selectedSeats);
	
});

$(document).on('click','.your-bookings-link',function(event){
	event.preventDefault();
	$('#owner-menu').hide();
	$('#your-bookings-div').show();
	getUserBookingHistory(localStorage.getItem("user_id"));
	getUserUpcomingTrips(localStorage.getItem("user_id"));
});
	
function getUserBookingHistory(userId)
{
	$.ajax({
      url: './bookingHistory?userId='+userId ,
      type: 'GET',
      success: function(data) {
  		 console.log(data);
  		 let i=1;
  		 var table=$("#booking-history-table");
		 table.find("tr:not(:first)").remove();
		 if(data.length==0)
		 {
			 var row = $("<tr>");
			 row.append($("<td colspan='12'>").text("No Bookings"));
			 table.append(row);
			 return;
			 
		 }
  		 $.each(data, function(index, object) {
			    
			    var row = $("<tr>");
		                row.append($("<td>").text(i));
		                row.append($("<td>").text(object.date));
		                row.append($("<td>").text(object.from));
		                row.append($("<td>").text(object.to));
		                row.append($("<td>").text(object.busName));
		                row.append($("<td>").text(object.busNumber));
		                row.append($("<td>").text(object.type));
		                row.append($("<td>").text(object.ac==1?'Yes':'No'));
		                row.append($("<td>").text(object.startTime));
		                row.append($("<td>").text(object.endTime));
		                row.append($("<td>").text(object.status));
		                
		                  
		                var viewTicketsButton = $('<button>')
		                .attr("details",JSON.stringify(object))
		                .attr("href","javascript:void(0)")
		                .attr("class","viewHistoryTicketsButton transitionLink")
			            .text('View Tickets');
			  			row.append($('<td>').append(viewTicketsButton));
			  			   
		                table.append(row);
	   					i++;
		 });
      },
      error:function(error)
      {
		  console.log(error);
		  alert(error);
	  }
    });
}



function getUserUpcomingTrips(userId)
{
	$.ajax({
      url: './upcomingTrips?userId='+userId ,
      type: 'GET',
      success: function(data) {
  		 console.log(data);
  		 let i=1;
  		 var table=$("#upcoming-trips-table");
		 table.find("tr:not(:first)").remove();
		 if(data.length==0)
		 {
			 var row = $("<tr>");
			 row.append($("<td colspan='13'>").text("No Bookings"));
			 table.append(row);
			 return;
			 
		 }
  		 $.each(data, function(index, object) {
			    
			    var row = $("<tr>");
		                row.append($("<td>").text(i));
		                row.append($("<td>").text(object.date));
		                row.append($("<td>").text(object.from));
		                row.append($("<td>").text(object.to));
		                row.append($("<td>").text(object.busName));
		                row.append($("<td>").text(object.busNumber));
		                row.append($("<td>").text(object.type));
		                row.append($("<td>").text(object.ac==1?'Yes':'No'));
		                row.append($("<td>").text(object.startTime));
		                row.append($("<td>").text(object.endTime));
		                row.append($("<td class='booking-status-column'>").text(object.status));
		                
		                  
		                var viewTicketsButton = $('<button>')
		                .attr("details",JSON.stringify(object))
		                .attr("href","javascript:void(0)")
		                .attr("class","viewUpcomingTicketsButton transitionLink")
			            .text('View Tickets');
			  			row.append($('<td>').append(viewTicketsButton));
			  			
			  			var cancelBookingButton = $('<button>')
		                .attr("booking",JSON.stringify(object))
		                .attr("href","javascript:void(0)")
		                .attr("class","cancelBookingButton")
			            .text('Cancel Booking');
			  			row.append($("<td class='cancel-booking-button-column'>").append(cancelBookingButton));
			  			   
		                table.append(row);
	   					i++;
		 });
      },
      error:function(error)
      {
		  console.log(error);
		  alert(error);
	  }
    });
}

$(document).on('click','.viewHistoryTicketsButton',function(event)
{
	event.preventDefault();
	$('#your-bookings-div').hide();
	$('#your-tickets-div').show();
	var trip=JSON.parse($(this).attr("details"));
	getUserHistoryTripTickets(trip.bookingId);
	
});

function getUserHistoryTripTickets(bookingId)
{
	$.ajax({
      url: './ticket?bookingId='+bookingId ,
      type: 'GET',
      success: function(data) {
  		 console.log(data);
  		 let i=1;
  		 var table=$("#tickets-table");
		 table.find("tr:not(:first)").remove();
		 if(data.length==0)
		 {
			 var row = $("<tr>");
			 row.append($("<td colspan='8'>").text("No Tickets"));
			 table.append(row);
			 return;
			 
		 }
		 var prize=0,refund=0;
  		 $.each(data, function(index, object) {
			    
			    var row = $("<tr>");
		                row.append($("<td>").text(i));
		                row.append($("<td>").text(object.seatNumber));
		                row.append($("<td>").text(object.type));
		                row.append($("<td>").text(object.name));
		                row.append($("<td>").text(object.gender));
		                row.append($("<td>").text(object.status));
		                row.append($("<td>").text("-"));
		                row.append($("<td>").text(object.prize));
		                row.append($("<td>").text(object.refund));
		                prize=prize+parseInt(object.prize);
		                refund=refund+parseInt(object.refund);
		               		   
		                table.append(row);
	   					i++;
		 });
		 var row = $("<tr>");
		 row.append($("<td colspan='7'>").text("Booking Cost"));
		 row.append($("<td colspan='2'>").text(prize));
		 table.append(row);
		 var row = $("<tr>");
		 row.append($("<td colspan='7'>").text("Refunded Amount"));
		 row.append($("<td colspan='2'>").text(refund));
		 table.append(row);
		 var row = $("<tr>");
		 row.append($("<td colspan='7'>").text("Total Expense"));
		 row.append($("<td colspan='2'>").text(prize-refund));
		 table.append(row);
      },
      error:function(error)
      {
		  console.log(error);
		  alert(error);
	  }
    });
}

$(document).on('click','.viewUpcomingTicketsButton',function(event)
{
	event.preventDefault();
	$('#your-bookings-div').hide();
	$('#your-tickets-div').show();
	var trip=JSON.parse($(this).attr("details"));
	getUserUpcomingTripTickets(trip.bookingId);
	
});

function getUserUpcomingTripTickets(bookingId)
{
	$.ajax({
      url: './ticket?bookingId='+bookingId ,
      type: 'GET',
      success: function(data) {
  		 console.log(data);
  		 let i=1;
  		 var table=$("#tickets-table");
		 table.find("tr:not(:first)").remove();
		 if(data.length==0)
		 {
			 var row = $("<tr>");
			 row.append($("<td colspan='8'>").text("No Tickets"));
			 table.append(row);
			 return;
			 
		 }
		 var prize=0,refund=0;
  		 $.each(data, function(index, object) {
			    
			    var row = $("<tr>");
		                row.append($("<td>").text(i));
		                row.append($("<td>").text(object.seatNumber));
		                row.append($("<td>").text(object.type));
		                row.append($("<td>").text(object.name));
		                row.append($("<td>").text(object.gender));
		                row.append($("<td class='ticket-status'>").text(object.status));
		                if(object.status=='Booked')
		                {
							var cancelUserTicketButton = $('<button>')
			                .attr("ticket",JSON.stringify(object))
			                .attr("href","javascript:void(0)")
			                .attr("class","cancelUserTicketButton")
				            .text('Cancel');
				  			row.append($("<td class='ticket-cancel-column'>").append(cancelUserTicketButton));
			  			
						}
						else
						{
							row.append($("<td  class='ticket-cancel-column'>").text(""));
						}
		                
		                row.append($("<td>").text(object.prize));
		                row.append($("<td>").text(object.refund));
		                prize=prize+parseInt(object.prize);
		                refund=refund+parseInt(object.refund);
		               		   
		                table.append(row);
	   					i++;
		 });
		 var row = $("<tr>");
		 row.append($("<td colspan='7'>").text("Booking Cost"));
		 row.append($("<td colspan='2'>").text(prize));
		 table.append(row);
		 var row = $("<tr>");
		 row.append($("<td colspan='7'>").text("Refunded Amount"));
		 row.append($("<td colspan='2'>").text(refund));
		 table.append(row);
		 var row = $("<tr>");
		 row.append($("<td colspan='7'>").text("Total Expense"));
		 row.append($("<td colspan='2'>").text(prize-refund));
		 table.append(row);
      },
      error:function(error)
      {
		  console.log(error);
		  alert(error);
	  }
    });
}
$(document).on('click','.cancelUserTicketButton',function(event)
{
	event.preventDefault();
	var ticket=JSON.parse($(this).attr("ticket"));
	if(confirm('Are you sure want to cancel the ticket?'))
	{
		userCancelTicket(ticket.ticketId,ticket.bookingId);
	}
	
	
});

function userCancelTicket(ticketId,bookingId)
{
	var data={};
	data['ticketId']=ticketId;
	data['userId']=parseInt(localStorage.getItem("user_id"));
	$.ajax({
      url: './cancelTicket',
      type: 'POST',
      contentType:"application/json",
	  data:JSON.stringify(data),
      success: function(res) {
  		 alert(res.success);
  		 getUserUpcomingTripTickets(bookingId);
	  },
	  error:function(error)
      {
		  console.log(error);
		  alert(error);
	  }
    });
}

$(document).on('click','.cancelBookingButton',function(event)
{
	event.preventDefault();
	var booking=JSON.parse($(this).attr("booking"));
	if(confirm('Are you sure want to cancel all tickets of this booking?'))
	{
		var data={};
		data['bookingId']=booking.bookingId;
		userId=parseInt(localStorage.getItem("user_id"));
		data['userId']=userId;
		
		$.ajax({
	      url: './cancelBooking',
	      type: 'POST',
	      contentType:"application/json",
		  data:JSON.stringify(data),
	      success: function(res) {
	  		 alert(res.success);
	  		 getUserUpcomingTrips(userId);
	  		 getUserBookingHistory(userId)
	  		 /*
	  		 var row = $(this).closest('tr');
	         var cell = row.find('.booking-status-column');
	         cell.text(res.status);
	         cell=row.find('.booking-cancel-button-column');
	         cell.text("-");
	         */
		  },
		  error:function(error)
	      {
			  console.log(error);
			  alert(error);
		  }
	    });
		
	}
	
	
});
 

$(document).on('click','.viewBusTripTickets',function(event)
{
	event.preventDefault();
	$('#trips-div').hide();
	$('#trip-tickets-div').show();
	var trip=JSON.parse($(this).attr("trip"));
	getBusTripTickets(trip.tripId);
});
  
 function getBusTripTickets(tripId)
 {
	 $.ajax({
	      url: './tripTickets?tripId='+tripId,
	      type: 'GET',
	      success: function(data) {
	  		 let i=1,prize=0,refund=0;
  		     var table=$("#trip-tickets-table");
		     table.find("tr:not(:first)").remove();
		     $.each(data, function(index, object) {
			    
			    var row = $("<tr>");
		                row.append($("<td>").text(i));
		                row.append($("<td>").text(object.seatNumber));
		                row.append($("<td>").text(object.type));
		                row.append($("<td>").text(object.name));
		                row.append($("<td>").text(object.gender));
		                row.append($("<td>").text(object.status));
		                //row.append($("<td>").text("-"));
		                row.append($("<td>").text(object.prize));
		                row.append($("<td>").text(object.refund));
		                prize=prize+parseInt(object.prize);
		                refund=refund+parseInt(object.refund);
		               		   
		                table.append(row);
	   					i++;
		 });
		 var row = $("<tr>");
		 row.append($("<td colspan='6'>").text("Booking Cost"));
		 row.append($("<td colspan='2'>").text(prize));
		 table.append(row);
		 var row = $("<tr>");
		 row.append($("<td colspan='6'>").text("Refunded Amount"));
		 row.append($("<td colspan='2'>").text(refund));
		 table.append(row);
		 var row = $("<tr>");
		 row.append($("<td colspan='6'>").text("Total Income"));
		 row.append($("<td colspan='2'>").text(prize-refund));
		 table.append(row);
	  		 
		  },
		  error:function(error)
	      {
			  console.log(error);
			  alert(error);
		  }
	    });
 } 
 
 $(document).on('click','.owner-access-request-link',function(event)
{
	event.preventDefault();
	$('#owner-menu').hide();
	$('#bus-owner-access-request-table-div').show();
	var isPending=0;
	$.ajax({
			url:'./ownerAccessRequest?userId='+localStorage.getItem("user_id"),
			type:'GET',
			success:function(res)
			{
					var table=$("#bus-owner-access-request-table");
		     		table.find("tr:not(:first)").remove();
		     		$.each(res, function(index, object) {
			    		var row = $("<tr>");
			    		row.append($("<td>").text(object.date));
		                row.append($("<td>").text(object.aadharNumber));
		                row.append($("<td>").text(object.panNumber));
		                row.append($("<td>").text(object.status));  		   
		                table.append(row);
	   					
	   					if(object.status=='Pending')
	   					isPending=1;
		 		  });
		 		  if(isPending==0)
					{
					 $('#bus-owner-access-request-div').show();
					 }
					 else
					 {
						 $('#bus-owner-access-request-div').hide();
					 }
			},
			error:function(error)
			{
			   console.log("Error occured while registration"+error);
			   alert("Error occured while registration"+error);
			}
		})
} );
 
 $(document).on('submit','#bus-owner-form',function(event)
{
	event.preventDefault();
	var aadhar=$('#aadharNumber').val();
		var format = /^\d{12}$/;
		if(!aadhar.match(format))
		{
			alert("Enter valid AadharNumber");
			$('#aadharNumber').focus();
			return;
		}
		
	var pan=$('#panNumber').val();
		
		if(pan.length < 10)
		{
			alert("Enter valid PAN Number");
			$('#panNumber').focus();
			return;
		}
		
		var data={
			'aadharNumber':aadhar,
			'panNumber':pan,
			'userId':localStorage.getItem("user_id")
		};
		console.log(data);
		$.ajax({
			url:'./ownerAccessRequest',
			type:'POST',
			contentType:"application/json",
			data:JSON.stringify(data),
			success:function(res)
			{
				if(res.success)
				{
					  $('#bus-owner-access-request-div').hide();
					   alert(res.success);
						var table=$("#bus-owner-access-request-table");
			    		var row = $("<tr>");
			    		var today = new Date();
						var date = today.toISOString().slice(0, 10);
			    		row.append($("<td>").text(date));
		                row.append($("<td>").text(aadhar));
		                row.append($("<td>").text(pan));
		                row.append($("<td>").text(res.status));  		   
		                table.append(row);
				}
				else if(res.error)
				{
					alert(res.error);
					$('#registerEmail').focus();
					return;
				}
			},
			error:function(error)
			{
			   console.log("Error occured while registration"+error);
			   alert("Error occured while registration"+error);
			}
		})
	
} );
 
 
 
 
  $(document).on('click','#backButton',function() {
	   console.log(contentStates);
       if (contentStates.length > 0) {
       var previousState = contentStates.pop();
       $("#body-content").html(previousState);
       console.log('content poped..'+contentStates.length);
      }
  });
  
 	$(document).on('click','#log-out-link',function()
	 {
		 localStorage.clear();
		 window.location.href = "index.html";
	 }
	 );


	 
});