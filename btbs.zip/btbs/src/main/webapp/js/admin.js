var contentStates=[];
$(document).ready(function() {

function pushState()
{
	 contentStates.push($("#body-content").html())
	 console.log("content pushed.."+contentStates.length);
}

 $(document).on('click','.transitionLink',function()
 {
	pushState();
 }
 );
 
 user_id=localStorage.getItem("user_id");
 user_name=localStorage.getItem("user_name");
 
 if(user_id==null)
 {
	 alert("Please Login");
	 window.location.href = "index.html";
	 
 }

$('#welcome-text').text("Welcome "+user_name);

$(document).on('click','.requests-link',function(event){
	event.preventDefault();
	$('#owner-menu').hide();
	$('#requests-div').show();
	getRequests();
	
});

function getRequests()
{
	$.ajax({
			url:'./accessRequest',
			type:'GET',
			success:function(res)
			{
				      
						var table=$("#requests-table");
		     		    table.find("tr:not(:first)").remove();
		     		    $.each(res, function(index, object) {
			    		var row = $("<tr>");
			    		row.append($("<td>").text(object.date));
			    		row.append($("<td>").text(object.name));
			    		row.append($("<td>").text(object.email))
		                row.append($("<td>").text(object.aadharNumber));
		                row.append($("<td>").text(object.panNumber));
		                
		                var approveButton = $('<button>')
		                .attr("details",JSON.stringify(object))
		                .attr("href","javascript:void(0)")
		                .attr("class","approveButton ")
			            .text('Approve');
			  			row.append($('<td>').append(approveButton));
			  			
			  			var rejectButton = $('<button>')
		                .attr("details",JSON.stringify(object))
		                .attr("href","javascript:void(0)")
		                .attr("class","rejectButton")
			            .text('Reject');
			  			row.append($("<td>").append(rejectButton)); 		   
		                table.append(row);
		                
		                });
				
			},
			error:function(error)
			{
			   console.log("Error occured while registration"+error);
			   alert("Error occured while registration"+error);
			}
		})
}

$(document).on('click','.approveButton',function(event) {
	event.preventDefault();
	var details=JSON.parse($(this).attr("details"));
	var data={};
	data["userId"]=details.userId;
	data["panNumber"]=details.panNumber;
	data["aadharNumber"]=details.aadharNumber;
	data["requestId"]=details.requestId;
	data["action"]="ACCEPT";
	if(confirm("Are you sure want to provide Bus Owner Access to the user ?"))
	{
		$.ajax({
	      url: './accessRequest',
	      type: 'POST',
	      contentType:"application/json",
		  data:JSON.stringify(data),
	      success: function(res) {
	  		 
	  		 getRequests();
	  		 
	  		 /*
	  		 var row = $(this).closest('tr');
	         var cell = row.find('.booking-status-column');
	         cell.text(res.status);
	         cell=row.find('.booking-cancel-button-column');
	         cell.text("-");
	         */
		  },
		  error:function(error)
	      {
			  console.log(error);
			  alert(error);
		  }
	    });
	}
	
});

$(document).on('click','.rejectButton',function(event) {
	event.preventDefault();
	var details=JSON.parse($(this).attr("details"));
	var data={};
	data["userId"]=details.userId;
	data["panNumber"]=details.panNumber;
	data["aadharNumber"]=details.aadharNumber;
	data["requestId"]=details.requestId;
	data["action"]="REJECT";
	if(confirm("Are you sure want to reject Bus Owner Access request of the user ?"))
	{
		$.ajax({
	      url: './accessRequest',
	      type: 'POST',
	      contentType:"application/json",
		  data:JSON.stringify(data),
	      success: function(res) {
	  		 
	  		 getRequests();
	  		 
	  		 /*
	  		 var row = $(this).closest('tr');
	         var cell = row.find('.booking-status-column');
	         cell.text(res.status);
	         cell=row.find('.booking-cancel-button-column');
	         cell.text("-");
	         */
		  },
		  error:function(error)
	      {
			  console.log(error);
			  alert(error);
		  }
	    });
	}
	
});


$(document).on('click','#backButton',function() {
	   console.log(contentStates);
       if (contentStates.length > 0) {
       var previousState = contentStates.pop();
       $("#body-content").html(previousState);
       console.log('content poped..'+contentStates.length);
      }
  });
  
 	$(document).on('click','#log-out-link',function()
	 {
		 localStorage.clear();
		 window.location.href = "index.html";
	 }
	 );


	 
});