package POJO;

public class Account 
{
	private int account_id;
	private String email;
	private String password;
	private int user_role_id;
	public Account(int account_id, String email, String password, int user_role_id) {
		super();
		this.account_id = account_id;
		this.email = email;
		this.password = password;
		this.user_role_id = user_role_id;
	}
	public int getAccount_id() {
		return account_id;
	}
	public void setAccount_id(int account_id) {
		this.account_id = account_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getUser_role_id() {
		return user_role_id;
	}
	public void setUser_role_id(int user_role_id) {
		this.user_role_id = user_role_id;
	}
	
	
}
