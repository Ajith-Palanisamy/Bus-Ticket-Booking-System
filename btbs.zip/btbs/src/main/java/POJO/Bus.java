package POJO;

public class Bus {
	private int busId;
	private String busName;
	private String busNumber;
	private String type;
	private int ac;
	private int capacity;
	private int isAvailable;
	private int ownerId;
	public Bus(int busId, String busName, String busNumber, String type, int ac, int capacity,int owerId,int isAvailable) {
		super();
		this.busId = busId;
		this.busName = busName;
		this.busNumber = busNumber;
		this.type = type;
		this.ac = ac;
		this.capacity=capacity;
		this.isAvailable = isAvailable;
		this.ownerId=ownerId;
	}
	public Bus(String busName, String busNumber, String type, int ac,int capacity,int ownerId) {
		super();
		this.busName = busName;
		this.busNumber = busNumber;
		this.type = type;
		this.capacity=capacity;
		this.ac = ac;
		this.ownerId=ownerId;
	}
	public Bus(String busName, String busNumber, String type, int ac) {
		super();
		this.busName = busName;
		this.busNumber = busNumber;
		this.type = type;
		this.ac = ac;
	}
	public Bus()
	{
		
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public String getBusNumber() {
		return busNumber;
	}
	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getAc() {
		return ac;
	}
	public void setAc(int ac) {
		this.ac = ac;
	}
	
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int getIsAvailable() {
		return isAvailable;
	}
	public void setIsAvailable(int isAvailable) {
		this.isAvailable = isAvailable;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	

}
