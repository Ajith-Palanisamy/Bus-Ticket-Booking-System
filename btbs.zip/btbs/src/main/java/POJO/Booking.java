package POJO;

import java.time.LocalDate;
import java.time.LocalTime;

public class Booking {
	private int bookingId;
	private int tripId;
	private int bookedBy;
	private LocalDate date;
	private String from;
	private String to;
	private LocalTime startTime;
	private LocalTime endTime;
	
	private String status;
	
	public Booking(int bookingId, int tripId, int bookedBy, String status) {
		this.bookingId = bookingId;
		this.tripId = tripId;
		this.bookedBy = bookedBy;
		this.status = status;
	}

	public Booking(int tripId, int bookedBy, String status) {
		this.tripId = tripId;
		this.bookedBy = bookedBy;
		this.status = status;
	}
	
	

	public Booking(int bookingId, int tripId, int bookedBy, LocalDate date, String from, String to, LocalTime startTime,
			LocalTime endTime, String status) {
		this.bookingId = bookingId;
		this.tripId = tripId;
		this.bookedBy = bookedBy;
		this.date = date;
		this.from = from;
		this.to = to;
		this.startTime = startTime;
		this.endTime = endTime;
		this.status = status;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getTripId() {
		return tripId;
	}

	public void setTripId(int tripId) {
		this.tripId = tripId;
	}

	public int getBookedBy() {
		return bookedBy;
	}

	public void setBookedBy(int bookedBy) {
		this.bookedBy = bookedBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public LocalTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}
	
	

}
