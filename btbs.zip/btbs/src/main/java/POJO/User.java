package POJO;

public class User 
{
	private int user_id;
	private String email;
	private String password;
	private String name;
	private String phoneNumber;
	private int roleId;
	private String role;
	private int wallet;
	
	public User(int user_id, String email,String password,String name, String phoneNumber, int roleId,String role,int wallet) {
		super();
		this.user_id = user_id;
		this.email=email;
		this.password=password;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.roleId=roleId;
		this.role=role;
		this.wallet = wallet;
	}
	
	public User()
	{
		super();
	}
	
	public User(String name,String email,String password,String phoneNumber)
	{
		super();
		this.name=name;
		this.email=email;
		this.password=password;
		this.phoneNumber = phoneNumber;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getWallet() {
		return wallet;
	}

	public void setWallet(int wallet) {
		this.wallet = wallet;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getRoleId() {
		return roleId;
	}

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	
	

}
