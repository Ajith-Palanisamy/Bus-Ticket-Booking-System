package POJO;

import java.time.LocalDate;
import java.time.LocalTime;

public class Schedule 
{
	private int scheduleId;
	private int busId;
	private String from;
	private String to;
	private LocalDate startDate;
	private LocalDate endDate;
	private LocalTime startTime;
	private LocalTime duration;
	private int seaterPrize;
	private int lowerSleeperPrize;
	private int upperSleeperPrize;
	private int isActive;
	
	public Schedule(int scheduleId, int busId, String from, String to, LocalDate startDate, LocalDate endDate,
			LocalTime startTime, LocalTime duration, int seaterPrize, int upperSleeperPrize, int lowerSleeperPrize,
			int isActive) {
		super();
		this.scheduleId = scheduleId;
		this.busId = busId;
		this.from = from;
		this.to = to;
		this.startDate = startDate;
		this.endDate = endDate;
		this.startTime = startTime;
		this.duration = duration;
		this.seaterPrize = seaterPrize;
		this.lowerSleeperPrize = lowerSleeperPrize;
		this.upperSleeperPrize = upperSleeperPrize;
		this.isActive = isActive;
	}

	public Schedule(int busId, String from, String to, LocalDate startDate, LocalDate endDate, LocalTime startTime,
			LocalTime duration, int seaterPrize, int upperSleeperPrize, int lowerSleeperPrize) {
		this.busId = busId;
		this.from = from;
		this.to = to;
		this.startDate = startDate;
		this.endDate = endDate;
		this.startTime = startTime;
		this.duration = duration;
		this.seaterPrize = seaterPrize;
		this.lowerSleeperPrize = lowerSleeperPrize;
		this.upperSleeperPrize = upperSleeperPrize;
	}

	public Schedule() {
	}

	public int getScheduleId() {
		return scheduleId;
	}

	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}

	public int getBusId() {
		return busId;
	}

	public void setBusId(int busId) {
		this.busId = busId;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public LocalTime getDuration() {
		return duration;
	}

	public void setDuration(LocalTime duration) {
		this.duration = duration;
	}

	public int getSeaterPrize() {
		return seaterPrize;
	}

	public void setSeaterPrize(int seaterPrize) {
		this.seaterPrize = seaterPrize;
	}

	public int getLowerSleeperPrize() {
		return lowerSleeperPrize;
	}

	public void setLowerSleeperPrize(int lowerSleeperPrize) {
		this.lowerSleeperPrize = lowerSleeperPrize;
	}

	public int getUpperSleeperPrize() {
		return upperSleeperPrize;
	}

	public void setUpperSleeperPrize(int upperSleeperPrize) {
		this.upperSleeperPrize = upperSleeperPrize;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	
	
	
	
	
	
}
