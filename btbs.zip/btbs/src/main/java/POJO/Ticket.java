package POJO;

public class Ticket 
{
	private int ticketId;
	private int bookingId;
	private String seatNumber;
	private String type;
	private String name;
	private String gender;
	private int prize;
	private int refund;
	private String status;
	public Ticket(int ticketId, int bookingId, String seatNumber, String type, String name, String gender, int prize,
			int refund,String status) {
		this.ticketId = ticketId;
		this.bookingId = bookingId;
		this.seatNumber = seatNumber;
		this.type = type;
		this.name = name;
		this.gender = gender;
		this.prize = prize;
		this.refund = refund;
		this.status=status;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	
	public String getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getPrize() {
		return prize;
	}
	public void setPrize(int prize) {
		this.prize = prize;
	}
	public int getRefund() {
		return refund;
	}
	public void setRefund(int refund) {
		this.refund = refund;
	}
	
	
}
