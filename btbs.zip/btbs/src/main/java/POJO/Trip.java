package POJO;

import java.time.LocalDate;
import java.time.LocalTime;

public class Trip {
	private int tripId;
	private int scheduleId;
	private String from;
	private String to;
	private LocalDate tripDate;
	private LocalTime startTime;
	private LocalTime endTime;
	private int seaterPrize;
	private int lowerSleeperPrize;
	private int upperSleeperPrize;
	private String status;
	
	public Trip(int tripId, int scheduleId, String from, String to, LocalDate tripDate, LocalTime startTime,
			LocalTime endTime, int seaterPrize, int lowerSleeperPrize, int upperSleeperPrize, String status) {
		this.tripId = tripId;
		this.scheduleId = scheduleId;
		this.from = from;
		this.to = to;
		this.tripDate = tripDate;
		this.startTime = startTime;
		this.endTime = endTime;
		this.seaterPrize = seaterPrize;
		this.lowerSleeperPrize = lowerSleeperPrize;
		this.upperSleeperPrize = upperSleeperPrize;
		this.status = status;
	}
	public int getTripId() {
		return tripId;
	}
	public void setTripId(int tripId) {
		this.tripId = tripId;
	}
	public int getScheduleId() {
		return scheduleId;
	}
	public void setScheduleId(int scheduleId) {
		this.scheduleId = scheduleId;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public LocalDate getTripDate() {
		return tripDate;
	}
	public void setTripDate(LocalDate tripDate) {
		this.tripDate = tripDate;
	}
	public LocalTime getStartTime() {
		return startTime;
	}
	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}
	public LocalTime getEndTime() {
		return endTime;
	}
	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}
	public int getSeaterPrize() {
		return seaterPrize;
	}
	public void setSeaterPrize(int seaterPrize) {
		this.seaterPrize = seaterPrize;
	}
	public int getLowerSleeperPrize() {
		return lowerSleeperPrize;
	}
	public void setLowerSleeperPrize(int lowerSleeperPrize) {
		this.lowerSleeperPrize = lowerSleeperPrize;
	}
	public int getUpperSleeperPrize() {
		return upperSleeperPrize;
	}
	public void setUpperSleeperPrize(int upperSleeperPrize) {
		this.upperSleeperPrize = upperSleeperPrize;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
