package DB;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBHandler 
{
	private static DBHandler obj;
	private DBHandler(){	}
	private static Connection con=null;
	private static String db="btbs";
	private static String username="root";
	private static String password="Ajith6382@pmp";
	
	
	public static DBHandler getInstance()
	{
		if(obj==null)
			obj=new DBHandler();
		 
		return obj;
	}
	
	public static Connection getConnection()
	{
		try
		{
			//System.out.println("inside create connection");
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+db,username,password);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//System.out.println("connection");
		return con;
		
	}
	
	
}

