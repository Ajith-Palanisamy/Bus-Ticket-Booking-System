package Controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.BufferedReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import Service.BusService;
import Service.Service;
import Service.ServiceProvider;
import Service.UserService;
import Utils.Util;
@WebServlet(name = "BusServlet", urlPatterns = {
	    "/bus"
	})
public class BusServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {
			 HttpSession session = request.getSession( );
			 JSONObject req=new JSONObject();
			 //int user_id=(int) request.getAttribute("user_id");
			 //int user_id=9;
			 int user_id=Integer.parseInt(request.getParameter("userId"));
			 req.put("ownerId",user_id);
			 BusService busService=(BusService)ServiceProvider.getInstance("BusService");
			 JSONArray res=busService.getBuses(req);
			
			 response.setContentType("application/json");
	         response.setStatus(HttpServletResponse.SC_OK);
			 response.getWriter().write(res.toString());
		 
	    } catch (Exception e) {
	    	System.out.println("Exception occured in servlet controller"+e);
	    	e.printStackTrace();
	        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	    }

	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {
			
			 JSONObject req=Util.getRequestBody(request);       
			 BusService busService=(BusService)ServiceProvider.getInstance("BusService");
			 JSONObject res=busService.add(req);
			
			 response.setContentType("application/json");
	         response.setStatus(HttpServletResponse.SC_CREATED);
			 response.getWriter().write(res.toString());
		 
	    } catch (Exception e) {
	    	System.out.println("Exception occured in servlet controller"+e);
	    	e.printStackTrace();
	        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	    }

	}

}
