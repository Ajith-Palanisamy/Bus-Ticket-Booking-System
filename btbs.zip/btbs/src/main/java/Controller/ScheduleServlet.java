package Controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.BufferedReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import Service.BusService;
import Service.ScheduleService;
import Service.Service;
import Service.ServiceProvider;
import Service.UserService;
import Utils.Util;
@WebServlet(name = "ScheduleServlet", urlPatterns = {
	    "/schedule"
	})
public class ScheduleServlet extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {
			 
			 JSONObject req=new JSONObject();
			 int busId=Integer.parseInt(request.getParameter("busId"));
			 req.put("busId",busId);
			 ScheduleService scheduleService=(ScheduleService)ServiceProvider.getInstance("ScheduleService");
			 JSONArray res=scheduleService.getSchedules(req);
			
			 response.setContentType("application/json");
	         response.setStatus(HttpServletResponse.SC_OK);
			 response.getWriter().write(res.toString());
		 
	    } catch (Exception e) {
	    	System.out.println("Exception occured in servlet controller"+e);
	    	e.printStackTrace();
	        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	    }

	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {
			
			 JSONObject req=Util.getRequestBody(request);       
			 ScheduleService scheduleService=(ScheduleService)ServiceProvider.getInstance("ScheduleService");
			 
			 JSONObject res=scheduleService.add(req);
			 
			 response.setContentType("application/json");
	         response.setStatus(HttpServletResponse.SC_OK);
			 response.getWriter().write(res.toString());
		 
	    } catch (Exception e) {
	    	System.out.println("Exception occured in servlet controller"+e);
	    	e.printStackTrace();
	        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	    }

	}

}
