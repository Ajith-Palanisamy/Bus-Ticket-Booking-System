package Controller;

import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import Service.BusService;
import Service.OwnerAccessRequestService;
import Service.ServiceProvider;
import Utils.Message;
import Utils.Util;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "OwnerAccessRequestServlet", urlPatterns = {
	    "/ownerAccessRequest"
	})
public class OwnerAccessRequestServlet extends HttpServlet
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {
			 
			 int userId=Integer.parseInt(request.getParameter("userId"));
			 OwnerAccessRequestService ownerAccessRequestService=(OwnerAccessRequestService)ServiceProvider.getInstance("OwnerAccessRequestService");
			 JSONArray res=ownerAccessRequestService.getRequests(userId);
			
			 response.setContentType("application/json");
	         response.setStatus(HttpServletResponse.SC_OK);
			 response.getWriter().write(res.toString());
		 
	    } catch (Exception e) {
	    	System.out.println("Exception occured in servlet controller"+e);
	    	e.printStackTrace();
	        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	    }

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {
			 
			 JSONObject req=Util.getRequestBody(request);
			 OwnerAccessRequestService ownerAccessRequestService=(OwnerAccessRequestService)ServiceProvider.getInstance("OwnerAccessRequestService");
			 
			 JSONObject res= ownerAccessRequestService.addRequest(req);
			 res.put("success",Message.REQUEST_SENT);
			 response.setContentType("application/json");
	         response.setStatus(HttpServletResponse.SC_OK);
			 response.getWriter().write(res.toString());
		 
	    } catch (Exception e) {
	    	System.out.println("Exception occured in servlet controller"+e);
	    	e.printStackTrace();
	        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	    }

	}
}
