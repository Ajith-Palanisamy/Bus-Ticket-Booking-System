package Controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.BufferedReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import Service.BusService;
import Service.TripService;
import Service.Service;
import Service.ServiceProvider;
import Service.UserService;
import Utils.Util;
@WebServlet(name = "CancelTicketServlet", urlPatterns = {
	    "/cancelTicket"
	})
public class CancelTicketServlet extends HttpServlet 
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try {
			 
			 JSONObject req=Util.getRequestBody(request);
			 
			 UserService userService=(UserService)ServiceProvider.getInstance("UserService");
			 JSONObject res=userService.cancelTicket(req);
			
			 response.setContentType("application/json");
	         response.setStatus(HttpServletResponse.SC_OK);
			 response.getWriter().write(res.toString());
		 
	    } catch (Exception e) {
	    	System.out.println("Exception occured in servlet controller"+e);
	    	e.printStackTrace();
	        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	    }

	}
	

}
