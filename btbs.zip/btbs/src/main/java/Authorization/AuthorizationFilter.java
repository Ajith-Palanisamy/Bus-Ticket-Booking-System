package Authorization;

import java.io.IOException;
import java.security.Key;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebFilter(urlPatterns = {"/trip"})
public class AuthorizationFilter extends HttpFilter{
	
	public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws IOException, ServletException {
		try {
		        String token = request.getHeader("Authorization");
		        
		        if (token != null ) {
		        	System.out.println(token);
		            Key key = AuthToken.key;//Keys.secretKeyFor(SignatureAlgorithm.HS256);
		            System.out.println("key-"+key);
		            Jws<Claims> claimsJws = Jwts.parserBuilder()
		                    .setSigningKey(key)
		                    .build()
		                    .parseClaimsJws(token);
		            
		            System.out.println("claimsJws"+claimsJws);
		            Claims claims = claimsJws.getBody();
		            Integer userId =claims.get("user_id",Integer.class);
		            //System.out.println("userId "+userId);
		            Integer userRoleId = claims.get("user_role_id", Integer.class);
		            //System.out.println("userRoleId "+userRoleId);
		            if(userRoleId==1 || userRoleId==2)
		            {
		            	request.setAttribute("userId",userId);
		            	request.setAttribute("userRoleId", userRoleId);
		                chain.doFilter(request, response);
		            }
		            else {
		                
		                HttpServletResponse httpResponse = (HttpServletResponse) response;
		                httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		                httpResponse.getWriter().write("Unauthorized");
		                return;
		            }
		        } 
		        else {
		            
		            HttpServletResponse httpResponse = (HttpServletResponse) response;
		            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		            httpResponse.getWriter().write("Unauthorized");
		            return;
		        }
		}
		catch(Exception e)
		{
			System.out.println("Exception in Filter "+e);
			e.printStackTrace();
		}
    }

}
