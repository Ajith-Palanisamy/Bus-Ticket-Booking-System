package Utils;

public class Message 
{
	public static final String PASSWORD_INVALID="Password incorrect";//login
	public static final String EMAIL_NOT_EXIST="User does not exist";//login
	public static final String USER_ALREADY_EXIST="User already exist";//register
	public static final String REGISTRATION_SUCCESSFUL="Registration successful";//register
	public static final String BUS_ADDED="Bus Added";
	public static final String TRIP_BOOKING_OPENED="Booking Opened";
	public static final String TRIP_CANCELLED="Trip Cancelled";
	public static final String TRIPS_CREATED="Trip(s) created";
	public static final String CANCELLED="Cancelled";
	public static final String BOOKED="Booked";
	public static final String CANCELLED_DUE_TO_UNAVAILABILITY="Cancelled due to unavailability";
	public static final String SERVER_SIDE_ERROR="Something went wrong..Try again later";//when error coourred while db operations
	public static final String BOOKED_SUCCESSFUL="Tickets booked successfully";
	public static final String CANCELLED_AND_REFUNDED="Cancelled and Refunded";
	public static final String BOOKING_CANCELLED="Booking cancelled";
	public static final String REQUEST_ACCEPTED="Accepted";
	public static final String REQUEST_REJECTED="Rejected";
	public static final String REQUEST_PENDING="Pending";
	public static final String REQUEST_SENT="Request sent";
}
