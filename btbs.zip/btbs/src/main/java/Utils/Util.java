package Utils;

import java.io.BufferedReader;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;

import jakarta.servlet.http.HttpServletRequest;

public class Util 
{
	private static Gson gson=new Gson();;
	public static JSONObject getRequestBody(HttpServletRequest request)
	{
		JSONObject json=null;
		try
		{
			StringBuilder requestBody = new StringBuilder();
	        String line;
	        BufferedReader reader = request.getReader();
	        while ((line = reader.readLine()) != null) {
	            requestBody.append(line);
	        }
	        JSONParser parser = new JSONParser();
	        json = (JSONObject)parser.parse(requestBody.toString());
	        
			return json;
	        
		}
		catch(Exception e)
		{
			System.out.println("Exception occured while parsing request body "+e);
			e.printStackTrace();
		}
		return json;
	}
	
	public static Gson getGsonInstance()
	{
		if(gson==null)
			gson=new Gson();
		
		return gson;

	}
}
