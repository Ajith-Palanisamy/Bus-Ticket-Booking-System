package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;

import DB.DBHandler;
import POJO.Ticket;
import Utils.Message;
import Utils.Util;

public class TicketDAO extends DAO{
	DBHandler obj=DBHandler.getInstance();
    Connection con = obj.getConnection();
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String sql;
    
    AccountDAO accountDAO=(AccountDAO)DAOProvider.getInstance("AccountDAO");
    UserDAO userDAO=(UserDAO)DAOProvider.getInstance("UserDAO");
    //BookingDAO bookingDAO=(BookingDAO)DAOProvider.getInstance("BookingDAO");
    
    public void bookTickets(int userId,int bookingId,JSONArray seats)
    {
    	try
    	{
    		int amount=0;
    		sql="insert into ticket(booking_id,seat_number,type,passenger_name,gender,prize,status) values(?,?,?,?,?,?,?)";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, bookingId);
    		ps.setString(7,Message.BOOKED);
    		for(int i=0;i<seats.size();i++)
    		{
    			JSONObject seat=(JSONObject) seats.get(i);
    			ps.setString(2,(String) seat.get("seatNumber"));
    			ps.setString(3,(String) seat.get("type"));
    			ps.setString(4,(String) seat.get("name"));
    			ps.setString(5,(String) seat.get("gender"));
    			int prize=(int)((long) seat.get("prize"));
    			ps.setInt(6,prize);
    			amount=amount+prize;
    			ps.addBatch();
    			
    		}
    		ps.executeBatch();
    		
    		int ownerId=getOwnerIdForBooking(bookingId);
    		userDAO.creditToOwner(ownerId,amount);
    		userDAO.debitFromUser(userId,amount);
    		
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    }
    
    
    public int getOwnerIdForTicket(int ticketId)
    {
    	try
    	{
	    	sql="select owner_id from bus_owner inner join bus on bus.owner_id=bus_owner.bus_owner_id "
	    			+ "inner join trip_schedule on trip_schedule.bus_id=bus.bus_id "
	    			+ "inner join trip on trip.trip_schedule_id=trip_schedule.trip_schedule_id "
	    			+ "inner join booking on booking.trip_id=trip.trip_id "
	    			+ "inner join ticket on ticket.booking_id=booking.booking_id and ticket.ticket_id=?";
	    	ps=con.prepareStatement(sql);
	    	ps.setInt(1, ticketId);
	    	rs=ps.executeQuery();
	    	if(rs.next())
	    		return rs.getInt("owner_id");
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	return -1;
    }
    
    
    public Ticket cancelTicket(int ticketId,int userId)
    {
    	try
    	{
    		
    		LocalDate date=getTripDateForTicket(ticketId);
    		sql="update ticket set status= CASE "
    				+ "WHEN ? > CURRENT_DATE THEN ? "
    				+ "ELSE ? END,refund= CASE "
    				+ "WHEN ? > CURRENT_DATE THEN prize "
    				+ "ELSE 0 END "
    				+ "WHERE ticket_id=? AND status=?";
    		
    		ps=con.prepareStatement(sql);
    		ps.setDate(1,Date.valueOf(date));
    		ps.setString(2,Message.CANCELLED_AND_REFUNDED);
    		ps.setString(3,Message.CANCELLED);
    		ps.setDate(4,Date.valueOf(date));
    		ps.setInt(5,ticketId);
    		ps.setString(6,Message.BOOKED);
    		ps.executeUpdate();
    		Ticket t=getTicket(ticketId);
    		
    		if(t.getStatus().equals(Message.CANCELLED_AND_REFUNDED))
    		{
    			userDAO.creditToUser(userId,t.getPrize());
    			int ownerId=getOwnerIdForTicket(ticketId);
        		userDAO.debitFromOwner(ownerId,t.getPrize());
    			
    		}
    		
    		/*
    		 sql="SELECT"
    		 		+ " COUNT(*) - SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) AS active_count"
    		 		+ "FROM ticket where booking_id=?";
    		 ps=con.prepareStatement(sql);
    		 ps.setString(1,Message.BOOKED);
    		 ps.setInt(2,t.getBookingId());
    		 rs=ps.executeQuery();
    		 int n=0;
    		 if(rs.next())
    			 n=rs.getInt("active_count");
    		 if(n==0)
    		 {
    			 sql="update booking set status=? where booking_id=?";
    			 ps=con.prepareStatement(sql);
    			 ps.setString(1,Message.CANCELLED);
    			 ps.setInt(2,t.getBookingId());
    			 ps.executeUpdate();
    		 }
    		*/
    		return t;	
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in cancelling ticket "+ex);
            ex.printStackTrace();
        }
    	return null;
    }
    public JSONArray getTicketsOfBooking(int bookingId)
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		sql="select ticket.ticket_id,seat_number,passenger_name,gender,prize,refund ,ticket.status,ticket.type "
    				+ "from ticket inner join booking on ticket.booking_id=booking.booking_id and booking.booking_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, bookingId);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			int ticketId=rs.getInt("ticket_id");
    			String seatNumber=rs.getString("seat_number");
    			String name=rs.getString("passenger_name");
    			String type=rs.getString("type");
    			String gender=rs.getString("gender");
    			int prize=rs.getInt("prize");
    			int refund=rs.getInt("refund");
    			String status=rs.getString("status");
    			
    			Ticket t=new Ticket(ticketId,bookingId,seatNumber,type,name,gender,prize,refund,status);
    			arr.add(toJSON(t));
    			
    		}
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving tickets "+ex);
            ex.printStackTrace();
        }
    	return arr;
    }
    
    public Ticket getTicket(int ticketId)
    {
    	
    	try
    	{
    		sql="select ticket.ticket_id,seat_number,passenger_name,gender,prize,refund ,ticket.status,ticket.type,booking.booking_id "
    				+ "from ticket inner join booking on ticket.booking_id=booking.booking_id and ticket.ticket_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, ticketId);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			int bookingId=rs.getInt("booking_id");
    			String seatNumber=rs.getString("seat_number");
    			String name=rs.getString("passenger_name");
    			String type=rs.getString("type");
    			String gender=rs.getString("gender");
    			int prize=rs.getInt("prize");
    			int refund=rs.getInt("refund");
    			String status=rs.getString("status");
    			
    			Ticket t=new Ticket(ticketId,bookingId,seatNumber,type,name,gender,prize,refund,status);
    			return t;
    			
    		}
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving tickets "+ex);
            ex.printStackTrace();
        }
    	return null;
    }
    
    
    public JSONObject toJSON(Ticket t)
    {
    	try
    	{
    		Gson g=Util.getGsonInstance();
			String jsonString=g.toJson(t);
			JSONParser parser = new JSONParser();
			JSONObject json=(JSONObject) parser.parse(jsonString);
			return json;
    	}
    	catch(Exception ex)
    	{
    		System.out.println("Exception in retriving Ticket JSON "+ex);
            ex.printStackTrace();
    	}
    	return null;
    }
    public LocalDate getTripDateForTicket(int ticketId)
    {
    	try
    	{
    		sql="select trip_date from trip inner join booking on trip.trip_id=booking.trip_id "
    				+ "inner join ticket on ticket.booking_id=booking.booking_id AND ticket.ticket_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, ticketId);
    		rs=ps.executeQuery();
    		if(rs.next())
    			return rs.getDate("trip_date").toLocalDate();
    	}
    	catch(Exception ex)
    	{
    		System.out.println("Exception in retriving Ticket JSON "+ex);
            ex.printStackTrace();
    	}
    	return null;
    }
    
    public JSONArray getTicketsOfTrip(int tripId)
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		sql="select ticket.ticket_id,seat_number,passenger_name,gender,prize,refund ,ticket.status,ticket.type,ticket.booking_id "
    				+ "from ticket inner join booking on ticket.booking_id=booking.booking_id and booking.trip_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, tripId);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			int ticketId=rs.getInt("ticket_id");
    			String seatNumber=rs.getString("seat_number");
    			String name=rs.getString("passenger_name");
    			String type=rs.getString("type");
    			String gender=rs.getString("gender");
    			int prize=rs.getInt("prize");
    			int refund=rs.getInt("refund");
    			String status=rs.getString("status");
    			int bookingId=rs.getInt("booking_id");
    			Ticket t=new Ticket(ticketId,bookingId,seatNumber,type,name,gender,prize,refund,status);
    			arr.add(toJSON(t));
    			
    		}
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving tickets "+ex);
            ex.printStackTrace();
        }
    	return arr;
    }
    
    public int getOwnerIdForBooking(int bookingId)
    {
    	try
    	{
	    	sql="select owner_id from bus_owner inner join bus on bus.owner_id=bus_owner.bus_owner_id "
	    			+ "inner join trip_schedule on trip_schedule.bus_id=bus.bus_id "
	    			+ "inner join trip on trip.trip_schedule_id=trip_schedule.trip_schedule_id "
	    			+ "inner join booking on booking.trip_id=trip.trip_id AND booking_id=?";
	    	ps=con.prepareStatement(sql);
	    	ps.setInt(1, bookingId);
	    	rs=ps.executeQuery();
	    	if(rs.next())
	    		return rs.getInt("owner_id");
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	return -1;
    }
}
