package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import DB.DBHandler;
import Utils.Message;

public class SeatingDAO extends DAO {
	DBHandler obj=DBHandler.getInstance();
    Connection con = obj.getConnection();
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String sql;
    
    public void add(int busId,String type,int rows)
    {
    	try
    	{
    		sql="insert into seating(bus_id,seat_number,type) values(?,?,?)";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1,busId);
    		char c='A';
    		String seatNumber;
    		if(type.equals("SEATER"))
    		{
    			for(int i=1;i<=rows;i++)
    			{
    				for(int j=1;j<=3;j++)
    				{
    					seatNumber=""+c+j;
    					ps.setString(2, seatNumber);
    					ps.setString(3,"SEATER");
    					ps.addBatch();
    				}
    				c++;
    			}
    		}
    		else if(type.equals("SLEEPER"))
    		{
    			for(int i=1;i<=rows;i++)
    			{
    				for(int j=1;j<=3;j++)
    				{
    					seatNumber="L"+c+j;
    					ps.setString(2, seatNumber);
    					ps.setString(3,"LOWER");
    					ps.addBatch();
    				}
    				for(int j=1;j<=3;j++)
    				{
    					seatNumber="U"+c+j;
    					ps.setString(2, seatNumber);
    					ps.setString(3,"UPPER");
    					ps.addBatch();
    				}
    				c++;
    			}
    		}
    		ps.executeBatch();
    		
    	}
    	catch(Exception ex)
    	{
    		System.out.println("Exception in add seatings "+ex);
            ex.printStackTrace();
    	}
    }
    
    
    public JSONArray getAvailableSeats(JSONObject json)
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		int tripId=(int)((long)json.get("tripId"));
    		int scheduleId=(int)((long)json.get("scheduleId"));
    		int busId=(int)((long)json.get("busId"));
    		
    		int seaterPrize=(int)((long)json.get("seaterPrize"));
    		int upperSleeperPrize=(int)((long)json.get("upperSleeperPrize"));
    		int lowerSleeperPrize=(int)((long)json.get("lowerSleeperPrize"));
    		
    		
    		//getBooked Tickets
    		ArrayList<String> bookedSeats=new ArrayList<String>();
    		sql="select ticket.seat_number from booking inner join ticket on booking.booking_id=ticket.booking_id and ticket.status=? and booking.status=? and booking.trip_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setString(1,Message.BOOKED);
    		ps.setString(2,Message.BOOKED );
    		ps.setInt(3,tripId);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			bookedSeats.add(rs.getString("seat_number"));
    		}
    		
    		sql="select * from seating where bus_id=? and isAvailable=1";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1,busId);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			String seatNumber=rs.getString("seat_number");
    			String type=rs.getString("type");
    			int prize=seaterPrize;
    			if(!bookedSeats.contains(seatNumber))
    			{
    				JSONObject seat=new JSONObject();
    				seat.put("seatNumber",seatNumber);
    				seat.put("type",type);
    				if(type.equals("SEATER"))
    					prize=seaterPrize;
    				else if(type.equals("LOWER"))
    					prize=lowerSleeperPrize;
    				else if(type.equals("UPPER"))
    					prize=upperSleeperPrize;
    				
    				seat.put("prize",prize);
    				arr.add(seat);
    			}
    		}
    		  		
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	return arr;
    	
    }

}
