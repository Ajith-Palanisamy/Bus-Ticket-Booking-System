package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


import DB.DBHandler;
import Utils.Message;

public class OwnerAccessRequestDAO extends DAO 
{
	DBHandler obj=DBHandler.getInstance();
    Connection con = obj.getConnection();
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String sql;
    
    public JSONArray getRequests(int userId)
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		sql="select * from request where user_id=? order by date";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, userId);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			JSONObject json=new JSONObject();
    			json.put("requsetId",rs.getInt("request_id"));
    			json.put("userId",rs.getInt("user_id"));
    			json.put("date", rs.getDate("date").toString());
    			json.put("panNumber",rs.getString("pan_number"));
    			json.put("aadharNumber",rs.getString("aadhar_number"));
    			json.put("status",rs.getString("status"));
    			
    			arr.add(json);
    		}
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	return arr;
    }
    
    public JSONObject addRequest(int userId,String aadharNumber,String panNumber)
    {
    	JSONObject json=new JSONObject();
    	try
    	{
    		sql="insert into request(user_id,aadhar_number,pan_number,date,status) values(?,?,?,?,?)";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, userId);
    		ps.setString(2, aadharNumber);
    		ps.setString(3, panNumber);
    		ps.setDate(4,Date.valueOf(LocalDate.now()));
    		ps.setString(5,Message.REQUEST_PENDING);
    		ps.executeUpdate();
    		json.put("status",Message.REQUEST_PENDING);
    		
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	return json;
    }
    
    public JSONArray getRequests()
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		sql="select request.*,account.email,user.name from request inner join account on request.user_id=account.account_id "
    				+ "inner join user on user.user_id=account.account_id where status=? order by date";
    		ps=con.prepareStatement(sql);
    		ps.setString(1,Message.REQUEST_PENDING);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			JSONObject json=new JSONObject();
    			json.put("requestId",rs.getInt("request_id"));
    			json.put("userId",rs.getInt("user_id"));
    			json.put("date", rs.getDate("date").toString());
    			json.put("panNumber",rs.getString("pan_number"));
    			json.put("aadharNumber",rs.getString("aadhar_number"));
    			json.put("email",rs.getString("email"));
    			json.put("name",rs.getString("name"));
    			
    			
    			arr.add(json);
    		}
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	return arr;
    }
    
    public void rejectRequest(int requestId)
    {
    	try
    	{
    		sql="update request set status=? where request_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setString(1,Message.REQUEST_REJECTED);
    		ps.setInt(2, requestId);
    		ps.executeUpdate();
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	
    }
    public void acceptRequest(int userId,int requestId,String aadhar,String pan)
    {
    	try
    	{
    		sql="update request set status=? where request_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setString(1,Message.REQUEST_ACCEPTED);
    		ps.setInt(2, requestId);
    		ps.executeUpdate();
    		
    		sql="insert into bus_owner(bus_owner_id,aadhar_number,pan_number) values(?,?,?)";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, userId);
    		ps.setString(2, aadhar);
    		ps.setString(3, pan);
    		ps.executeUpdate();
    		
    		sql="update account set user_role_id=2 where account_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, userId);
    		ps.executeUpdate();
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	
    }
}
