package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;

import DB.DBHandler;
import POJO.Booking;
import POJO.Bus;
import Utils.Message;
import Utils.Util;

public class BookingDAO extends DAO {
	DBHandler obj=DBHandler.getInstance();
    Connection con = obj.getConnection();
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String sql;
    
    TicketDAO ticketDAO=(TicketDAO)DAOProvider.getInstance("TicketDAO");
    UserDAO userDAO=(UserDAO)DAOProvider.getInstance("UserDAO");
    public Booking bookTickets(JSONObject json)
    {
    	JSONObject res=new JSONObject();
    	try
    	{
    		int tripId=Integer.parseInt((String) json.get("tripId"));
    		int userId=Integer.parseInt((String)json.get("userId"));
    		Booking obj=new Booking(tripId,userId,Message.BOOKED);
    		
    		sql="insert into booking(trip_id,booked_by,status) values(?,?,?)";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1,obj.getTripId());
    		ps.setInt(2,obj.getBookedBy());
    		ps.setString(3,obj.getStatus());
    		
    		ps.executeUpdate();
    		
    		int bookingId=getRecentBookingId();
    		obj.setBookingId(bookingId);
    		
    		ticketDAO.bookTickets(userId,bookingId,(JSONArray) json.get("seats"));
    		
    		return obj;
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving bus "+ex);
            ex.printStackTrace();
        }
    	
    	return null;
    }
    
    public int getRecentBookingId()
    {
    	try
    	{
    		sql="select booking_id from booking order by booking_id desc limit 1";
    		ps=con.prepareStatement(sql);
    		rs=ps.executeQuery();
    		if(rs.next())
    			return rs.getInt("booking_id");
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving bus "+ex);
            ex.printStackTrace();
        }
    	return -1;
    	
    }
    
    public JSONArray getBookingHistory(int userId)
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		sql="select trip.trip_id,trip.trip_date,`from`,`to`,trip.start_time,trip.end_time,booking.booking_id,booking.status,"
    				+ "bus.bus_name,bus.bus_number,bus.type,bus.ac "
    				+ " from booking inner join trip on booking.trip_id=trip.trip_id and booking.booked_by = ? "
    				+ "inner join trip_schedule on trip_schedule.trip_schedule_id=trip.trip_schedule_id "
    				+ "inner join bus on bus.bus_id=trip_schedule.bus_id "
    				+ "where ( (CONCAT(trip.trip_date,' ',trip.start_time) <= CURRENT_TIMESTAMP)  OR booking.status!= ? )"
    				+ " group by booking.booking_id order by trip.trip_date,trip.start_time";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, userId);
    		ps.setString(2,Message.BOOKED);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			int tripId=rs.getInt("trip_id");
    			LocalDate date=rs.getDate("trip_date").toLocalDate();
    			String from=rs.getString("from");
    			String to=rs.getString("to");
    			LocalTime startTime=rs.getTime("start_time").toLocalTime();
    			LocalTime endTime=rs.getTime("end_time").toLocalTime();
    			int bookingId=rs.getInt("booking_id");
    			String status=rs.getString("status");
    			String busName=rs.getString("bus_name");
    			String busNumber=rs.getString("bus_number");
    			String type=rs.getString("type");
    			int ac=rs.getInt("ac");
    			Bus bus=new Bus(busName,busNumber,type,ac);
    		
    			Booking b=new Booking(bookingId,tripId,userId,date,from,to,startTime,endTime,status);
    			JSONObject json=getJson(b);
    			json.put("busName",bus.getBusName());
    			json.put("busNumber",bus.getBusNumber());
    			json.put("type",bus.getType());
    			json.put("ac", bus.getAc());
    			arr.add(json);
    		}
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving bookingsHistory "+ex);
            ex.printStackTrace();
        }
    	return arr;
    }
    
    public JSONObject getJson(Booking b)
    {
    	JSONObject json=new JSONObject();
    	try
    	{

	    	json.put("tripId",b.getTripId());
	    	json.put("date",b.getDate().toString());
	    	json.put("from",b.getFrom());
	    	json.put("to",b.getTo());
	    	json.put("startTime",b.getStartTime().toString());
	    	json.put("endTime",b.getEndTime().toString());
	    	json.put("bookingId",b.getBookingId());
	    	json.put("bookedBy",b.getBookedBy());
	    	json.put("status",b.getStatus());
    	    	
        	
    	}
    	catch (Exception ex) 
   	    {
            System.out.println("Exception in retriving booking json "+ex);
            ex.printStackTrace();
        }
    	return json;
    }
    
    public JSONArray getUpcomingTrips(int userId)
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		String sql="select trip.trip_id,trip.trip_date,trip_schedule.from,trip_schedule.to,trip.start_time,trip.end_time,booking.booking_id,booking.status,"
    				+ "bus.bus_name,bus.bus_number,bus.type,bus.ac "
    				+ " from booking inner join trip on booking.trip_id=trip.trip_id and booking.booked_by = ? "
    				+ "inner join trip_schedule on trip_schedule.trip_schedule_id=trip.trip_schedule_id "
    				+ "inner join bus on bus.bus_id=trip_schedule.bus_id "
    				+ "where ( (CONCAT(trip.trip_date,' ',trip.start_time) > CURRENT_TIMESTAMP)  AND booking.status = ? )"
    				+ " group by booking.booking_id order by trip.trip_date,trip.start_time";
    		PreparedStatement ps=con.prepareStatement(sql);
    		ps.setInt(1, userId);
    		ps.setString(2,Message.BOOKED);
    		ResultSet rs=ps.executeQuery();
    		//System.out.println(ps.toString());
    		while(rs.next())
    		{
    			int tripId=rs.getInt("trip_id");
    			LocalDate date=rs.getDate("trip_date").toLocalDate();
    			String from=rs.getString("from");
    			String to=rs.getString("to");
    			LocalTime startTime=rs.getTime("start_time").toLocalTime();
    			LocalTime endTime=rs.getTime("end_time").toLocalTime();
    			int bookingId=rs.getInt("booking_id");
    			String status=rs.getString("status");
    			String busName=rs.getString("bus_name");
    			String busNumber=rs.getString("bus_number");
    			String type=rs.getString("type");
    			int ac=rs.getInt("ac");
    			Bus bus=new Bus(busName,busNumber,type,ac);
    		
    			Booking b=new Booking(bookingId,tripId,userId,date,from,to,startTime,endTime,status);
    			JSONObject json=getJson(b);
    			json.put("busName",bus.getBusName());
    			json.put("busNumber",bus.getBusNumber());
    			json.put("type",bus.getType());
    			json.put("ac", bus.getAc());
    			arr.add(json);
    		}
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving bookings "+ex);
            ex.printStackTrace();
        }
    	return arr;
    }
    
    public void cancelBooking(int bookingId,int userId)
    {
    	try
    	{
    		sql="select ticket_id,prize from ticket inner join booking on booking.booking_id=ticket.booking_id AND booking.booking_id=? AND booking.status= ? AND ticket.status=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1,bookingId);
    		ps.setString(2,Message.BOOKED);
    		ps.setString(3, Message.BOOKED);
    		rs=ps.executeQuery();
    		ArrayList<Integer> tickets=new ArrayList<Integer>();
    		int amount=0;
    		while(rs.next()) {
    			int ticketId=rs.getInt("ticket_id");
    			tickets.add(ticketId);
    			amount=amount+rs.getInt("prize");
    		}
    		LocalDate date=getTripDateForBooking(bookingId);
    		LocalDate currentDate = LocalDate.now();
    		boolean isRefund=false;
            if (date.isAfter(currentDate)) {
                isRefund=true;
            }
    		sql="update ticket set status= CASE "
    				+ "WHEN ? > CURRENT_DATE THEN ? "
    				+ "ELSE ? END,refund= CASE "
    				+ "WHEN ? > CURRENT_DATE THEN prize "
    				+ "ELSE 0 END "
    				+ "WHERE ticket_id=? AND status=?";
    		
    		ps=con.prepareStatement(sql);
    		ps.setDate(1,Date.valueOf(date));
    		ps.setString(2,Message.CANCELLED_AND_REFUNDED);
    		ps.setString(3,Message.CANCELLED);
    		ps.setDate(4,Date.valueOf(date));
    		
    		ps.setString(6,Message.BOOKED);
    		for(int i=0;i<tickets.size();i++)
    		{
    			int ticketId=tickets.get(i);
    			ps.setInt(5,ticketId);
    			ps.addBatch();
    			
    		}
    		ps.executeBatch();
    		
    		
    		sql="update booking set status=? where booking_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setString(1, Message.CANCELLED);
    		ps.setInt(2,bookingId);
    		ps.executeUpdate();
    		
    		if(isRefund)
    		{
    			userDAO.creditToUser(userId,amount);
    			int ownerId=getOwnerIdForBooking(bookingId);
    			userDAO.debitFromOwner(ownerId, amount);
    		}
    		
    		
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving bookings "+ex);
            ex.printStackTrace();
        }
    }
    
    public LocalDate getTripDateForBooking(int bookingId)
    {
    	try
    	{
    		sql="select trip_date from trip inner join booking on trip.trip_id=booking.trip_id AND booking.booking_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, bookingId);
    		rs=ps.executeQuery();
    		if(rs.next())
    			return rs.getDate("trip_date").toLocalDate();
    	}
    	catch(Exception ex)
    	{
    		System.out.println("Exception in retriving Ticket JSON "+ex);
            ex.printStackTrace();
    	}
    	return null;
    }
    
    public int getOwnerIdForBooking(int bookingId)
    {
    	try
    	{
	    	sql="select owner_id from bus_owner inner join bus on bus.owner_id=bus_owner.owner_id "
	    			+ "inner join trip_schedule on trip_schedule.bus_id=bus.bus_id "
	    			+ "inner join trip on trip.trip_schedule_id=trip_schedule.trip_schedule_id "
	    			+ "inner join booking on booking.trip_id=trip.trip_id AND booking_id=?";
	    	ps=con.prepareStatement(sql);
	    	ps.setInt(1, bookingId);
	    	rs=ps.executeQuery();
	    	if(rs.next())
	    		return rs.getInt("owner_id");
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	return -1;
    }
    
}
