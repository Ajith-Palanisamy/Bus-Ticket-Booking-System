package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import DB.DBHandler;
import POJO.Schedule;
import POJO.Trip;
import Utils.Message;

public class TripDAO extends DAO{
	DBHandler obj=DBHandler.getInstance();
    Connection con = obj.getConnection();
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String sql;
    
    
    UserDAO userDAO=(UserDAO)DAOProvider.getInstance("UserDAO");
    BookingDAO bookingDAO=(BookingDAO)DAOProvider.getInstance("BookingDAO");
    
	public ArrayList<String> checkForUnavailableDates(int busId,LocalDate startDate,LocalDate endDate,LocalTime startTime,LocalTime endTime)
	{
		ArrayList<String> arr=new ArrayList<String>();
		try
		{			
			sql="select trip.trip_date from trip INNER JOIN trip_schedule on trip.trip_schedule_id=trip_schedule.trip_schedule_id "
					+ "where trip_schedule.bus_id=? AND trip.status=? AND (trip_date BETWEEN ? AND ?) "
					+ "AND ((? BETWEEN trip.start_time  AND trip.end_time) OR (? BETWEEN trip.start_time  AND trip.end_time) "
					+ "OR((trip.end_time <trip.start_time) AND ((? BETWEEN trip.start_time AND '23:59:00' ) OR (? BETWEEN '00:00:00' AND trip.end_time  ) OR "
					+ "(? BETWEEN trip.start_time AND '23:59:00' ) OR (? BETWEEN '00:00:00' AND trip.end_time)))) "
					+ "group by trip.trip_date";
			
			ps = con.prepareStatement(sql);
	    	ps.setInt(1,busId);
	    	ps.setString(2,Message.TRIP_BOOKING_OPENED);
	    	ps.setDate(3,Date.valueOf(startDate));
	    	ps.setDate(4,Date.valueOf(endDate));
	    	
	    	ps.setTime(5,Time.valueOf(startTime));
	    	ps.setTime(6,Time.valueOf(endTime));
	    	
	    	ps.setTime(7,Time.valueOf(startTime));
	    	ps.setTime(8,Time.valueOf(startTime));
	    	
	    	ps.setTime(9,Time.valueOf(endTime));
	    	ps.setTime(10,Time.valueOf(endTime));
	     
	    	rs=ps.executeQuery();
	    	String executedQuery = rs.getStatement().toString();
	    	System.out.println("SQL "+executedQuery);
	    	
	    	while(rs.next())
        	{
        		arr.add(rs.getDate("trip_date").toString());
        	}
		}
		catch (SQLException ex) 
   	    {
            System.out.println("Exception in  checkForUnavailableDates"+ex);
            ex.printStackTrace();
        }
		return arr;
	}
	
	public void add(Schedule s,LocalTime endTime)
	{
		try
		{
			sql="insert into trip(trip_schedule_id,trip_date,start_time,end_time,seater_prize,upper_sleeper_prize,lower_sleeper_prize,status) values(?,?,?,?,?,?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setInt(1,s.getScheduleId());
			ps.setTime(3,Time.valueOf(s.getStartTime()));
			ps.setTime(4,Time.valueOf(endTime));
			ps.setInt(5,s.getSeaterPrize());
			ps.setInt(6,s.getUpperSleeperPrize());
			ps.setInt(7,s.getLowerSleeperPrize());
			ps.setString(8,Message.TRIP_BOOKING_OPENED);
			
			int days = (int)ChronoUnit.DAYS.between(s.getStartDate(),s.getEndDate())+1;
			LocalDate tripDate=s.getStartDate();
    		for(int j=days;j>0;j--)
    		{
        			ps.setDate(2,Date.valueOf(tripDate));
        			ps.addBatch();
        			tripDate=tripDate.plusDays(1);
    		}
			ps.executeBatch();
		}
		catch (SQLException ex) 
   	    {
            System.out.println("Exception in  checkForUnavailableDates"+ex);
            ex.printStackTrace();
        }
	}
	
	public JSONArray getTrips(int busId,int userId,int userRoleId)
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		sql="select trip.*,`from`,`to` from trip inner join trip_schedule on trip_schedule.trip_schedule_id=trip.trip_schedule_id "
    				+ "inner join bus on bus.bus_id=trip_schedule.bus_id AND bus.bus_id = ? "
    				+ "where ( bus.owner_id = ? OR ? = 1 ) order by trip_date";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1,busId);
    		ps.setInt(2,userId);
    		ps.setInt(3, userRoleId);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			Trip t=new Trip(rs.getInt("trip_id"),rs.getInt("trip_schedule_id"),rs.getString("from"),rs.getString("to"),rs.getDate("trip_date").toLocalDate(),rs.getTime("start_time").toLocalTime(),rs.getTime("end_time").toLocalTime(),rs.getInt("seater_prize"),rs.getInt("upper_sleeper_prize"),rs.getInt("lower_sleeper_prize"),rs.getString("status"));
    			arr.add(getJSON(t));
    		}
    		
    	}catch (SQLException ex) 
	    {
	        System.out.println("Exception in getting trips "+ex);
	        ex.printStackTrace();
	    }
    	return arr;
    }
	
	public void cancelTrip(int tripId,int ownerId)
	{
		try
		{
			//System.out.println("tripId "+tripId);
			HashMap<Integer,Integer> booking =new HashMap<Integer,Integer>();
			sql="select booking_id,booked_by from booking inner join trip on trip.trip_id=booking.trip_id AND trip.trip_id=? AND booking.status=?";
			ps=con.prepareStatement(sql);
			ps.setInt(1,tripId);
			ps.setString(2,Message.BOOKED);
			rs=ps.executeQuery();
			while(rs.next())
			{
				booking.put(rs.getInt("booking_id"),rs.getInt("booked_by"));
			}
			for(Map.Entry<Integer,Integer> e:booking.entrySet())
			{
				int bookingId=e.getKey();
				int userId=e.getValue();
				sql="select ticket_id,prize from ticket inner join booking on booking.booking_id=ticket.booking_id AND booking.booking_id=? AND booking.status= ? AND ticket.status=?";
	    		ps=con.prepareStatement(sql);
	    		ps.setInt(1,bookingId);
	    		ps.setString(2,Message.BOOKED);
	    		ps.setString(3, Message.BOOKED);
	    		rs=ps.executeQuery();
	    		ArrayList<Integer> tickets=new ArrayList<Integer>();
	    		int amount=0;
	    		while(rs.next()) {
	    			int ticketId=rs.getInt("ticket_id");
	    			tickets.add(ticketId);
	    			amount=amount+rs.getInt("prize");
	    		}
	    		LocalDate date=bookingDAO.getTripDateForBooking(bookingId);
	    		LocalDate currentDate = LocalDate.now();
	    		boolean isRefund=false;
	            if (date.isAfter(currentDate)) {
	                isRefund=true;
	            }
	    		sql="update ticket set status=?,refund=prize where ticket_id=?";
	    		ps=con.prepareStatement(sql);
	    		ps.setString(1,Message.TRIP_CANCELLED);
	    		for(int j=0;j<tickets.size();j++)
	    		{
	    			int ticketId=tickets.get(j);
	    			ps.setInt(2,ticketId);
	    			ps.addBatch();
	    			
	    		}
	    		ps.executeBatch();
	    		
	    		sql="update booking set status=? where booking_id=?";
	    		ps=con.prepareStatement(sql);
	    		ps.setString(1, Message.TRIP_CANCELLED);
	    		ps.setInt(2,bookingId);
	    		ps.executeUpdate();
	    		
	    		if(isRefund)
	    		{
	    			userDAO.creditToUser(userId,amount);
	    			//int ownerId=bookingDAO.getOwnerIdForBooking(bookingId);
	    			userDAO.debitFromOwner(ownerId, amount);
	    		}    		
			}
			sql="update trip set status=? where trip_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setString(1, Message.CANCELLED);
    		ps.setInt(2,tripId);
    		ps.executeUpdate();
			
		}
		catch (SQLException ex) 
	    {
	        System.out.println("Exception in adding schedule "+ex);
	        ex.printStackTrace();
	    }
	}
	
	
    public JSONObject getJSON(Trip s)
    {
    	JSONObject json=new JSONObject();
    	json.put("scheduleId",s.getScheduleId());
    	json.put("tripId",s.getTripId());
    	json.put("from",s.getFrom());
    	json.put("to",s.getTo());
    	json.put("tripDate",s.getTripDate().toString());
    	json.put("startTime",s.getStartTime().toString());
    	json.put("endTime",s.getEndTime().toString());
    	json.put("seaterPrize",s.getSeaterPrize());
    	json.put("upperSleeperPrize",s.getUpperSleeperPrize());
    	json.put("lowerSleeperPrize",s.getLowerSleeperPrize());
    	json.put("status",s.getStatus());
    	return json;
    }
}
