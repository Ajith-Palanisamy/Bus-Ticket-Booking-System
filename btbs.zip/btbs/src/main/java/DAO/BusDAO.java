package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.mindrot.jbcrypt.BCrypt;

import DB.DBHandler;
import POJO.Account;
import POJO.Bus;
import Utils.Message;

public class BusDAO extends DAO {
	DBHandler obj=DBHandler.getInstance();
    Connection con = obj.getConnection();
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String sql;
    public Bus getBus(int busId)
    {
	     Bus bus=null;
	   	 try {
	            ps = con.prepareStatement("select bus.* from bus where bus.bus_id = ?");
	            ps.setInt(1,busId);
	            rs=ps.executeQuery();
	            while(rs.next())
	            {
	            	bus=new Bus(rs.getInt("bus_id"),rs.getString("bus_name"),rs.getString("bus_number"),rs.getString("type"),rs.getInt("ac"),rs.getInt("capacity"),rs.getInt("owner_id"),rs.getInt("isAvailable"));
	                break;
	            }
	                     
	        } catch (SQLException ex) 
	   	    {
	            System.out.println("Exception in retriving bus "+ex);
	            ex.printStackTrace();
	        }
	   	 return bus; 
    }
    public Bus add(Bus bus)
    {
	   	 try {
	            sql="insert into bus(bus_name,bus_number,type,ac,capacity,owner_id) values(?,?,?,?,?,?)";
	            ps=con.prepareStatement(sql);
	            ps.setString(1,bus.getBusName());
	            ps.setString(2,bus.getBusNumber());
	            ps.setString(3,bus.getType());
	            ps.setInt(4, bus.getAc());
	            ps.setInt(5,bus.getCapacity());
	            ps.setInt(6,bus.getOwnerId());
	            ps.executeUpdate();
	            
	            bus=getBus();
	            
	            return bus;
	                     
	        } catch (SQLException ex) 
	   	    {
	            System.out.println("Exception in adding bus "+ex);
	            ex.printStackTrace();
	        }
	   	 return null;
    	
    }
    public Bus getBus()//Recently added bus
    {
	     Bus bus=null;
	   	 try {
	            ps = con.prepareStatement("select bus.* from bus order by bus_id desc limit 1");
	            rs=ps.executeQuery();
	            while(rs.next())
	            {
	            	bus=new Bus(rs.getInt("bus_id"),rs.getString("bus_name"),rs.getString("bus_number"),rs.getString("type"),rs.getInt("ac"),rs.getInt("capacity"),rs.getInt("owner_id"),rs.getInt("isAvailable"));
	                break;
	            }
	                     
	        } catch (SQLException ex) 
	   	    {
	            System.out.println("Exception in retriving bus "+ex);
	            ex.printStackTrace();
	        }
	   	 return bus; 
    }
    public JSONArray getBuses(int ownerId)
    {
    	JSONArray arr=new JSONArray();
	     Bus bus=null;
	   	 try {
	            ps = con.prepareStatement("select bus.* from bus where owner_id=? order by bus_id");
	            ps.setInt(1, ownerId);
	            rs=ps.executeQuery();
	            while(rs.next())
	            {
	            	bus=new Bus(rs.getInt("bus_id"),rs.getString("bus_name"),rs.getString("bus_number"),rs.getString("type"),rs.getInt("ac"),rs.getInt("capacity"),rs.getInt("owner_id"),rs.getInt("isAvailable"));
	                arr.add(getJSON(bus));
	            }
	                     
	        } catch (SQLException ex) 
	   	    {
	            System.out.println("Exception in retriving buses "+ex);
	            ex.printStackTrace();
	        }
	   	 return arr; 
    }
    
    public JSONObject getJSON(Bus b)
    {
    	JSONObject json=new JSONObject();
    	json.put("busId",b.getBusId());
    	json.put("busName",b.getBusName());
    	json.put("busNumber",b.getBusNumber());
    	json.put("type",b.getType());
    	json.put("ac",b.getAc());
    	json.put("capacity",b.getCapacity());
    	json.put("isAvailable",b.getIsAvailable());
    	
    	return json;
    }
    
    public JSONArray getAvailableBuses(JSONObject json)
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		String from=(String) json.get("from");
    		String to=(String) json.get("to");
    		String tripDate=(String) json.get("tripDate");
    		//System.out.println("TripDate "+tripDate);
    		sql="select bus.bus_id,bus.bus_name,bus.bus_number,bus.type,bus.ac,trip.trip_id,(bus.capacity - COUNT(ticket_id) ) as available_tickets,"
    				+ "trip.seater_prize,trip.upper_sleeper_prize,trip.lower_sleeper_prize,trip.start_time,trip.end_time,trip_schedule.trip_schedule_id from bus "
    				+ "inner join trip_schedule on bus.bus_id=trip_schedule.bus_id and bus.isAvailable=1 and trip_schedule.isActive=1 and trip_schedule.from =? and trip_schedule.to=? "
    				+ "inner join trip on trip.trip_schedule_id=trip_schedule.trip_schedule_id and trip.status=? and trip.trip_date=? "
    				+ "left join booking on booking.trip_id=trip.trip_id and booking.status=? "
    				+ "left join ticket on booking.booking_id=ticket.booking_id and ticket.status=? "
    				+ "where CONCAT(trip.trip_date,' ',trip.start_time) > CURRENT_TIMESTAMP group by trip.trip_id having available_tickets > 0 order by trip.start_time";
    		
    		ps=con.prepareStatement(sql);
    		ps.setString(1, from);
    		ps.setString(2, to);
    		ps.setString(3,Message.TRIP_BOOKING_OPENED);
    		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            
            LocalDate date = LocalDate.parse(tripDate, formatter);
    		ps.setDate(4, Date.valueOf(date));
    		ps.setString(5,Message.BOOKED);
    		ps.setString(6,Message.BOOKED);
    		
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			JSONObject details=new JSONObject();
    			details.put("busId", rs.getInt("bus_id"));
    			details.put("busName",rs.getString("bus_name"));
    			details.put("busNumber",rs.getString("bus_number"));
    			details.put("type", rs.getString("type"));
    			details.put("ac",rs.getInt("ac"));
    			details.put("availableTickets", rs.getInt("available_tickets"));
    			details.put("tripId",rs.getInt("trip_id"));
    			details.put("seaterPrize",rs.getInt("seater_prize"));
    			details.put("upperSleeperPrize",rs.getInt("upper_sleeper_prize"));
    			details.put("lowerSleeperPrize",rs.getInt("lower_sleeper_prize"));
    			details.put("startTime",rs.getTime("start_time").toString());
    			details.put("endTime", rs.getTime("end_time").toString());
    			details.put("scheduleId",rs.getInt("trip_schedule_id"));
    			arr.add(details);
    			
    		}
    		
    		//System.out.println(ps.toString());
    		  		
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving buses "+ex);
            ex.printStackTrace();
        }
    	return arr;
    	
    }

}
