package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.simple.JSONObject;
import org.mindrot.jbcrypt.BCrypt;

import DB.DBHandler;
import POJO.User;
import POJO.Account;


public class UserDAO extends DAO
{
	DBHandler obj=DBHandler.getInstance();
    Connection con = obj.getConnection();
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String sql;
    
    AccountDAO accountDAO=(AccountDAO)DAOProvider.getInstance("AccountDAO");
    
    public User getUser(String email)
    {
	     User user=null;
	   	 try {
	            ps = con.prepareStatement("select account.*,user_role.user_role,user.* from account inner join user_role on account.user_role_id=user_role.user_role_id inner join user on account.account_id=user.user_id where email=?");
	            ps.setString(1,email);
	            rs=ps.executeQuery();
	            while(rs.next())
	            {
	            	user=new User(rs.getInt("account_id"),rs.getString("email"),rs.getString("password"),rs.getString("name"),rs.getString("phone_number"),rs.getInt("user_role_id"),rs.getString("user_role"),rs.getInt("wallet"));
	                break;
	            }
	                     
	        } catch (SQLException ex) 
	   	    {
	            System.out.println("Exception in retriving user "+ex);
	            ex.printStackTrace();
	        }
	   	 return user; 
    }
    public User addUser(User user)
    {
	   	 try {
	   		 	String hashPwd = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt(10));
	   		    String sql="insert into account(email,password,user_role_id) values(?,?,?)";
	   		    ps=con.prepareStatement(sql);
	   		    ps.setString(1,user.getEmail());
	   		    ps.setString(2,hashPwd);
	   		    ps.setInt(3,3);
	            ps.executeUpdate();
	            
	            Account account=accountDAO.getAccount(user.getEmail());
	            int user_id=account.getAccount_id();
	            
	            sql="insert into user(user_id,name,phone_number) values(?,?,?)";
	            ps=con.prepareStatement(sql);
	            ps.setInt(1, user_id);
	            ps.setString(2,user.getName());
	            ps.setString(3,user.getPhoneNumber());
	            ps.executeUpdate();
	            
	            return getUser(user.getEmail());
	                     
	        } catch (SQLException ex) 
	   	    {
	            System.out.println("Exception in retriving user "+ex);
	            ex.printStackTrace();
	        }
	   	 return null;
    	
    }
    
    public void creditToOwner(int ownerId,int amount)
    {
    	try
    	{
    		sql="update bus_owner set wallet=wallet+? where bus_owner_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, amount);
    		ps.setInt(2,ownerId);
    		ps.executeUpdate();
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in crediting to owner "+ex);
            ex.printStackTrace();
        }
    }
    
    public void debitFromOwner(int ownerId,int amount)
    {
    	try
    	{
    		sql="update bus_owner set wallet=wallet-? where bus_owner_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, amount);
    		ps.setInt(2,ownerId);
    		ps.executeUpdate();
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in crediting to owner "+ex);
            ex.printStackTrace();
        }
    }
    
    
    public void creditToUser(int userId,int amount)
    {
    	try
    	{
    		sql="update user set wallet=wallet+? where user_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, amount);
    		ps.setInt(2,userId);
    		ps.executeUpdate();
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in crediting to user "+ex);
            ex.printStackTrace();
        }
    }
    
    public void debitFromUser(int userId,int amount)
    {
    	try
    	{
    		sql="update user set wallet=wallet-? where user_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, amount);
    		ps.setInt(2,userId);
    		ps.executeUpdate();
    	}
    	catch (SQLException ex) 
   	    {
            System.out.println("Exception in crediting to user "+ex);
            ex.printStackTrace();
        }
    }

    
    
    
    
}
