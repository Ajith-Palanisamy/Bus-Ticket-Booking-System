package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import DB.DBHandler;
import POJO.Account;

public class AccountDAO extends DAO
{

	DBHandler obj=DBHandler.getInstance();
    Connection con = obj.getConnection();
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String sql;
    
    public Account getAccount(String email)
    {
    	Account account=null;
    	try
    	{
    		sql="select * from account where email=?";
    		ps=con.prepareStatement(sql);
    		ps.setString(1, email);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			account=new Account(rs.getInt("account_id"),rs.getString("email"),rs.getString("password"),rs.getInt("user_role_id"));
    			break;
    		}
    	}catch (SQLException ex) 
   	    {
            System.out.println("Exception in retriving user "+ex);
            ex.printStackTrace();
        }
    	return account;
    	
    }
    
    

}
