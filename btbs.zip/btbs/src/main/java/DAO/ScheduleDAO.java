package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import DB.DBHandler;
import POJO.Schedule;
import Utils.Message;

public class ScheduleDAO extends DAO{
	DBHandler obj=DBHandler.getInstance();
    Connection con = obj.getConnection();
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String sql;
    
    
    TripDAO tripDAO=(TripDAO)DAOProvider.getInstance("TripDAO");
    
    public Schedule add(Schedule s)
    {
    	try
    	{
    		sql="insert into trip_schedule(bus_id,`from`,`to`,schedule_start_date,schedule_end_date,trip_start_time,trip_duration,seater_prize,upper_sleeper_prize,lower_sleeper_prize) values(?,?,?,?,?,?,?,?,?,?)";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1,s.getBusId());
    		ps.setString(2,s.getFrom());
    		ps.setString(3,s.getTo());
    		ps.setDate(4,java.sql.Date.valueOf(s.getStartDate()));
    		ps.setDate(5,java.sql.Date.valueOf(s.getEndDate()));
    		ps.setTime(6,java.sql.Time.valueOf(s.getStartTime()));
    		ps.setTime(7,java.sql.Time.valueOf(s.getDuration()));
    		ps.setInt(8,s.getSeaterPrize());
    		ps.setInt(9, s.getUpperSleeperPrize());
    		ps.setInt(10, s.getLowerSleeperPrize());
    		ps.executeUpdate();
    		
    		int scheduleId=getId();
    		s.setScheduleId(scheduleId);
    		s.setIsActive(1);
    		return s;
    		
    	}catch (SQLException ex) 
   	    {
            System.out.println("Exception in adding schedule "+ex);
            ex.printStackTrace();
        }
   	 return null;
    }
    
    public int getId()//get recently added schedule_id
    {
    	try {
	    	sql="select trip_schedule_id from trip_schedule order by trip_schedule_id desc limit 1";
	    	ps=con.prepareStatement(sql);
	    	rs=ps.executeQuery();
	    	if(rs.next())
	    		return rs.getInt(1);
    	}catch (SQLException ex) 
	    {
	        System.out.println("Exception in adding schedule "+ex);
	        ex.printStackTrace();
	    }
    	return -1;
    }
    
    public JSONArray getSchedules(int busId)
    {
    	JSONArray arr=new JSONArray();
    	try
    	{
    		sql="select * from trip_schedule where bus_id = ? and isActive = ? AND trip_schedule.schedule_end_date >= CURRENT_DATE";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1,busId);
    		ps.setInt(2,1);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			Schedule s=new Schedule(rs.getInt("trip_schedule_id"),rs.getInt("bus_id"),rs.getString("from"),rs.getString("to"),rs.getDate("schedule_start_date").toLocalDate(),rs.getDate("schedule_end_date").toLocalDate(),rs.getTime("trip_start_time").toLocalTime(),rs.getTime("trip_duration").toLocalTime(),rs.getInt("seater_prize"),rs.getInt("upper_sleeper_prize"),rs.getInt("lower_sleeper_prize"),rs.getInt("isActive"));
    			arr.add(getJSON(s));
    
    		}
    		
    	}catch (SQLException ex) 
	    {
	        System.out.println("Exception in adding schedule "+ex);
	        ex.printStackTrace();
	    }
    	return arr;
    }
    
    public JSONObject getJSON(Schedule s)
    {
    	JSONObject json=new JSONObject();
    	json.put("scheduleId",s.getScheduleId());
    	json.put("busId",s.getBusId());
    	json.put("from",s.getFrom());
    	json.put("to",s.getTo());
    	json.put("startDate",s.getStartDate().toString());
    	json.put("endDate",s.getEndDate().toString());
    	json.put("startTime",s.getStartTime().toString());
    	json.put("duration",s.getDuration().toString());
    	json.put("seaterPrize",s.getSeaterPrize());
    	json.put("upperSleeperPrize",s.getUpperSleeperPrize());
    	json.put("lowerSleeperPrize",s.getLowerSleeperPrize());
    	json.put("isActive",s.getIsActive());
    	return json;
    }
    
    public void cancelSchedule(int scheduleId,int ownerId)
    {
    	try
    	{
    		ArrayList<Integer> trips=new ArrayList<Integer>();
    		sql="select trip_id from trip inner join trip_schedule on trip_schedule.trip_schedule_id=trip.trip_schedule_id AND trip.status=? "
    				+ "AND trip.trip_schedule_id=? ";
    		ps=con.prepareStatement(sql);
    		ps.setString(1,Message.TRIP_BOOKING_OPENED);
    		ps.setInt(2, scheduleId);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    			trips.add(rs.getInt("trip_id"));
    		}
    		for(int i=0;i<trips.size();i++)
    		{
    			
    			tripDAO.cancelTrip(trips.get(i),ownerId);
    		}
    		
    		sql="update trip_schedule set isActive=0 where trip_schedule_id=?";
    		ps=con.prepareStatement(sql);
    		ps.setInt(1, scheduleId);
    		ps.executeUpdate();
    		
    		
    	}
    	catch (SQLException ex) 
	    {
	        System.out.println("Exception in deleting schedule "+ex);
	        ex.printStackTrace();
	    }
    }
    

}
