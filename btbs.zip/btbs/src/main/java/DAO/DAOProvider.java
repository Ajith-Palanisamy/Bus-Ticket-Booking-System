package DAO;

public class DAOProvider 
{
	private static UserDAO userDAO;
	private static AccountDAO accountDAO;
	private static BusDAO busDAO;
	private static BookingDAO bookingDAO;
	private static TripDAO tripDAO;
	private static TicketDAO ticketDAO;
	private static SeatingDAO seatingDAO;
	private static ScheduleDAO scheduleDAO;
	private static OwnerAccessRequestDAO ownerAccessRequestDAO;
	public static DAO getInstance(String s)
	{
		if(s.equals("UserDAO"))
		{
			if(userDAO==null)
				userDAO=new UserDAO();
			
			return userDAO;
		}
		
		if(s.equals("OwnerAccessRequestDAO"))
		{
			if(ownerAccessRequestDAO==null)
				ownerAccessRequestDAO=new OwnerAccessRequestDAO();
			
			return ownerAccessRequestDAO;
		}
		
		if(s.equals("AccountDAO"))
		{
			if(accountDAO==null)
				accountDAO=new AccountDAO();
			
			return accountDAO;
		}
		if(s.equals("BusDAO"))
		{
			if(busDAO==null)
				busDAO=new BusDAO();
			
			return busDAO;
		}
		if(s.equals("SeatingDAO"))
		{
			if(seatingDAO==null)
				seatingDAO=new SeatingDAO();
			
			return seatingDAO;
		}
		
		if(s.equals("ScheduleDAO"))
		{
			if(scheduleDAO==null)
				scheduleDAO=new ScheduleDAO();
			
			return scheduleDAO;
		}
		
		if(s.equals("TripDAO"))
		{
			if(tripDAO==null)
				tripDAO=new TripDAO();
			
			return tripDAO;
		}
		if(s.equals("BookingDAO"))
		{
			if(bookingDAO==null)
				bookingDAO=new BookingDAO();
			
			return bookingDAO;
		}
		
		if(s.equals("TicketDAO"))
		{
			if(ticketDAO==null)
				ticketDAO=new TicketDAO();
			
			return ticketDAO;
		}
		return null;
	}

}
