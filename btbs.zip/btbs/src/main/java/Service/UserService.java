package Service;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.mindrot.jbcrypt.BCrypt;

import Authorization.AuthToken;
import POJO.Booking;
import POJO.Ticket;
import POJO.User;
import Utils.Message;
import DAO.AccountDAO;
import DAO.BookingDAO;
import DAO.DAOProvider;
import DAO.TicketDAO;
import DAO.UserDAO;
public class UserService extends Service
{
	UserDAO userDAO=(UserDAO) DAOProvider.getInstance("UserDAO");
	AccountDAO accountDAO=(AccountDAO)DAOProvider.getInstance("AccountDAO");
	BookingDAO bookingDAO=(BookingDAO) DAOProvider.getInstance("BookingDAO");
	TicketDAO ticketDAO=(TicketDAO)DAOProvider.getInstance("TicketDAO");
	public JSONObject login(JSONObject req)
    {
		 String email=(String) req.get("email");
		 String password=(String) req.get("password");
	   	 JSONObject res=new JSONObject();
	   	 try {
   		 	User user=(User) userDAO.getUser(email);
            if(user!=null)
            {
           	 boolean check = BCrypt.checkpw(password,(String)user.getPassword());
           	 if(check)
           	 {
	                 res.put("user_id",user.getUser_id());
	                 res.put("name",user.getName());
	                 res.put("user_role_id",user.getRoleId());
	                 //res.put("user_role", user.getRole());
	                 res.put("token",AuthToken.generateToken(user.getEmail(),user.getUser_id(),user.getRoleId(),user.getRole()));
	                
           	 }
           	 else
           	 {
           		 res.put("error",Message.PASSWORD_INVALID);
           	 }
            }
            else
            {
           	     res.put("error",Message.EMAIL_NOT_EXIST);
            }
         } 
	   	 catch (Exception ex) {
           res.put("error",Message.SERVER_SIDE_ERROR);
           System.out.println("Exception occured while user login "+ex);
           ex.printStackTrace();
	     }
	   	 return res;
    }
	
	public JSONObject register(JSONObject req)
	{
		String name=(String)req.get("name");
		String email=(String)req.get("email");
		String password=(String)req.get("password");
		String mobileNumber=(String)req.get("mobileNumber");
		
		JSONObject res=new JSONObject();
		try
		{
			User user=(User) userDAO.getUser(email);
			if(user!=null)
			{
				res.put("error",Message.USER_ALREADY_EXIST);
			}
			else
			{
				user=new User(name,email,password,mobileNumber);
			    user=(User)userDAO.addUser(user);
			    
			    res.put("success",Message.REGISTRATION_SUCCESSFUL);
			    res.put("user_id",user.getUser_id());
                res.put("name",user.getName());
                res.put("user_role_id",user.getRoleId());
                res.put("user_role", user.getRole());
			    
			}
		}
		catch (Exception ex) {
			System.out.println("Exception occured while user registration "+ex);
	        ex.printStackTrace();
	        res.put("error",Message.SERVER_SIDE_ERROR);
	    }
	   	return res;
	}
	
	public JSONObject bookTickets(JSONObject req)
	{
		JSONObject res=new JSONObject();
		try
		{
			Booking b=bookingDAO.bookTickets(req); 
			res.put("bookingId", b.getBookingId());
			res.put("success",Message.BOOKED_SUCCESSFUL);
		}
		catch (Exception ex) {
			System.out.println("Exception occured while user registration "+ex);
	        ex.printStackTrace();
	        res.put("error",Message.SERVER_SIDE_ERROR);
	    }
	   	return res;
	}
	
	public JSONObject cancelTicket(JSONObject req)
	{
		JSONObject res=new JSONObject();
		try
		{
			int ticketId=(int)((long)req.get("ticketId"));
    		int userId=(int)((long)req.get("userId"));
			Ticket t=ticketDAO.cancelTicket(ticketId,userId); 
			res.put("success","Ticket "+t.getStatus().toLowerCase());
		}
		catch (Exception ex) {
			System.out.println("Exception occured while user registration "+ex);
	        ex.printStackTrace();
	        res.put("error",Message.SERVER_SIDE_ERROR);
	    }
	   	return res;
	}
	
	public JSONObject cancelBooking(JSONObject req)
	{
		JSONObject res=new JSONObject();
		try
		{
			int bookingId=(int)((long)req.get("bookingId"));
    		int userId=(int)((long)req.get("userId"));
			bookingDAO.cancelBooking(bookingId,userId); 
			res.put("success",Message.BOOKING_CANCELLED);
			res.put("status",Message.CANCELLED);
			
		}
		catch (Exception ex) {
			System.out.println("Exception occured while user registration "+ex);
	        ex.printStackTrace();
	        res.put("error",Message.SERVER_SIDE_ERROR);
	    }
	   	return res;
	}
	public JSONArray getBookingHistory(JSONObject req)
	{
		JSONArray res=new JSONArray();
		try
		{
			int userId=(int)req.get("userId");
			return bookingDAO.getBookingHistory(userId);
		}
		catch(Exception ex)
		{
			
	        System.out.println("Exception occured while adding Bus "+ex);
	        ex.printStackTrace();
		}
		return res;
	}
	public JSONArray getUpcomingTrips(JSONObject req)
	{
		JSONArray res=new JSONArray();
		try
		{
			int userId=(int)req.get("userId");
			return bookingDAO.getUpcomingTrips(userId);
		}
		catch(Exception ex)
		{
			
	        System.out.println("Exception occured while adding Bus "+ex);
	        ex.printStackTrace();
		}
		return res;
	}
	

}

