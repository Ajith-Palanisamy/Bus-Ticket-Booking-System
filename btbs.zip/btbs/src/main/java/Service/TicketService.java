package Service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import DAO.DAOProvider;
import DAO.TicketDAO;
import POJO.Booking;
import Utils.Message;

public class TicketService extends Service {
	
	TicketDAO ticketDAO=(TicketDAO)DAOProvider.getInstance("TicketDAO");
	
	public JSONArray getTicketsOfBooking(JSONObject req)
	{
		JSONArray res=new JSONArray();
		try
		{
			int bookingId=(int)req.get("bookingId");
			return ticketDAO.getTicketsOfBooking(bookingId);
		}
		catch(Exception ex)
		{
			
	        System.out.println("Exception occured while getting tickets"+ex);
	        ex.printStackTrace();
		}
		return res;
	}
	public JSONArray getTicketsOfTrip(JSONObject req)
	{
		JSONArray res=new JSONArray();
		try
		{
			int tripId=(int)req.get("tripId");
			return ticketDAO.getTicketsOfTrip(tripId);
		}
		catch(Exception ex)
		{
			
	        System.out.println("Exception occured while getting tickets"+ex);
	        ex.printStackTrace();
		}
		return res;
	}

}
