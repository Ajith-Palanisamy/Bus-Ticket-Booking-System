package Service;

public class ServiceProvider {
	private static Service userService=new UserService();
	private static Service busService=new BusService();
	private static Service scheduleService=new ScheduleService();
	private static Service tripService=new TripService();
	private static Service ticketService=new TicketService();
	private static Service bookingService=new BookingService();
	
	private static Service ownerAccessRequestService=new OwnerAccessRequestService();
	
	public static Service getInstance(String s)
	{
		if(s.equals("UserService"))
			return userService;
		
		if(s.equals("OwnerAccessRequestService"))
			return ownerAccessRequestService;
		
		if(s.equals("BusService"))
			return busService;
		
		if(s.equals("ScheduleService"))
		return scheduleService;
		
		if(s.equals("TripService"))
			return tripService;
		
		if(s.equals("BookingService"))
			return bookingService;
		
		if(s.equals("TicketService"))
			return ticketService;
		
		return null;
	}

}
