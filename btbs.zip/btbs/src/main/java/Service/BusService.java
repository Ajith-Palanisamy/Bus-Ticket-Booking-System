package Service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import DAO.BusDAO;
import DAO.DAOProvider;
import DAO.SeatingDAO;
import POJO.Bus;
import Utils.Message;

public class BusService extends Service {
	BusDAO busDAO=(BusDAO)DAOProvider.getInstance("BusDAO");
	SeatingDAO seatingDAO=(SeatingDAO)DAOProvider.getInstance("SeatingDAO");
	
	public JSONObject add(JSONObject req)
	{
		JSONObject res=new JSONObject();
		try
		{
			int capacity=0;
			String type=(String)req.get("type");
			int seaterRows=Integer.parseInt((String)req.get("seaterRows"));
			int sleeperRows=Integer.parseInt((String)req.get("sleeperRows"));
			if(type.equals("SEATER"))
			{
				capacity=seaterRows * 3;
			}
			else if(type.equals("SLEEPER"))
			{
				capacity=sleeperRows * 3 * 2;
			}
			int ownerId=Integer.parseInt((String)req.get("ownerId"));
			int ac=Integer.parseInt((String) req.get("ac"));
			Bus obj=new Bus((String)req.get("busName"),(String)req.get("busNumber"),type,ac,capacity,ownerId);
			obj=busDAO.add(obj);
			int busId=obj.getBusId();
			
			if(type.equals("SEATER"))
			{
				seatingDAO.add(busId,type,seaterRows);
			}
			else if(type.equals("SLEEPER"))
			{
				seatingDAO.add(busId,type,sleeperRows);
			}
			
			JSONObject bus=busDAO.getJSON(obj);
			res.put("bus", bus);
			res.put("success",Message.BUS_ADDED);	
		}
		catch(Exception ex)
		{
			res.put("error",Message.SERVER_SIDE_ERROR);
	        System.out.println("Exception occured while adding Bus "+ex);
	        ex.printStackTrace();
		}
		return res;
	}
	
	public JSONArray getBuses(JSONObject req)
	{
		JSONArray res=new JSONArray();
		try
		{
			int ownerId=(int)req.get("ownerId");
			return busDAO.getBuses(ownerId);
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while retriving Bus "+ex);
	        ex.printStackTrace();
		}
		return res;
		
	}
	
	public JSONArray getAvailableBuses(JSONObject req)
	{
		JSONArray res=new JSONArray();
		try
		{
			return busDAO.getAvailableBuses(req);
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while retriving Available Buses "+ex);
	        ex.printStackTrace();
		}
		return res;
		
	}

}
