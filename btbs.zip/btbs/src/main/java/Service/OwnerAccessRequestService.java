package Service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import DAO.DAOProvider;
import DAO.OwnerAccessRequestDAO;
import Utils.Message;

public class OwnerAccessRequestService extends Service {
	
	OwnerAccessRequestDAO ownerAccessRequestDAO=(OwnerAccessRequestDAO) DAOProvider.getInstance("OwnerAccessRequestDAO");
	
	
	public JSONArray getRequests(int userId)
	{
		try
		{
			return ownerAccessRequestDAO.getRequests(userId);
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while getting tickets"+ex);
	        ex.printStackTrace();
		}
		return null;
	}
	public JSONArray getRequests()
	{
		try
		{
			return ownerAccessRequestDAO.getRequests();
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while getting tickets"+ex);
	        ex.printStackTrace();
		}
		return null;
	}
	
	public JSONObject addRequest(JSONObject req)
	{
		try
		{
			int userId=Integer.parseInt((String) req.get("userId"));
			String panNumber=(String) req.get("panNumber");
			String aadharNumber=(String) req.get("aadharNumber");
			return ownerAccessRequestDAO.addRequest(userId,aadharNumber,panNumber);
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while getting tickets"+ex);
	        ex.printStackTrace();
		}
		return null;
	}
	public JSONObject analyzeRequest(JSONObject req)
	{
		JSONObject res=new JSONObject();
		try
		{
			int userId=(int)((long)req.get("userId"));
			int requestId=(int)((long) req.get("requestId"));
			String panNumber=(String) req.get("panNumber");
			String aadharNumber=(String) req.get("aadharNumber");
			String action=(String)req.get("action");
			if(action.equalsIgnoreCase("ACCEPT"))
			{
				ownerAccessRequestDAO.acceptRequest(userId,requestId,aadharNumber,panNumber);
				res.put("status", Message.REQUEST_ACCEPTED);
			}
			else if(action.equalsIgnoreCase("REJECT"))
			{
				ownerAccessRequestDAO.rejectRequest(requestId);
				res.put("status", Message.REQUEST_REJECTED);
			}
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while getting tickets"+ex);
	        ex.printStackTrace();
		}
		return res;
	}

}
