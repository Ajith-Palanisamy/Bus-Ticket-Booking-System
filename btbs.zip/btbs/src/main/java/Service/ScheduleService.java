package Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import DAO.ScheduleDAO;
import DAO.DAOProvider;
import DAO.SeatingDAO;
import DAO.TripDAO;
import POJO.Schedule;
import Utils.Message;

public class ScheduleService extends Service {
	ScheduleDAO scheduleDAO=(ScheduleDAO)DAOProvider.getInstance("ScheduleDAO");
	TripDAO tripDAO=(TripDAO)DAOProvider.getInstance("TripDAO");
	
	public JSONObject add(JSONObject req)
	{
		JSONObject res=new JSONObject();
		try
		{
			String from=(String)req.get("from");
			String to=(String)req.get("to");
			LocalTime startTime=LocalTime.parse((String)req.get("startTime"));
            LocalTime duration=LocalTime.parse((String)req.get("tripDuration"));
            LocalDate startDate=LocalDate.parse((String)req.get("startDate"));
            LocalDate endDate=LocalDate.parse((String)req.get("endDate"));
			int busId=Integer.parseInt((String)req.get("busId"));
			int seaterPrize=Integer.parseInt((String)req.get("seaterPrize"));
			int upperSleeperPrize=Integer.parseInt((String)req.get("upperSleeperPrize"));
			int lowerSleeperPrize=Integer.parseInt((String)req.get("lowerSleeperPrize"));
			
			LocalTime endTime=startTime.plusHours(duration.getHour())
                    .plusMinutes(duration.getMinute())
                    .plusSeconds(duration.getSecond());

			Schedule obj=new Schedule(busId,from,to,startDate,endDate,startTime,duration,seaterPrize,upperSleeperPrize,lowerSleeperPrize);
			
			ArrayList<String>arr=tripDAO.checkForUnavailableDates(busId,startDate,endDate,startTime,endTime);
			if(arr.size()>0)
			{
				String s=arr.get(0);
				for(int i=1;i<arr.size() && i<5;i++)
				{
					s=s+","+arr.get(i);
				}
				res.put("error","The below dates are unavailable for the given schedule "+s);
				return res;
			}
				
			obj=scheduleDAO.add(obj);
			int scheduleId=obj.getScheduleId();
			
			tripDAO.add(obj,endTime);
			JSONObject s=scheduleDAO.getJSON(obj);
			res.put("schedule",s);
			res.put("success",Message.TRIPS_CREATED);	
		}
		catch(Exception ex)
		{
			res.put("error",Message.SERVER_SIDE_ERROR);
	        System.out.println("Exception occured while adding Schedule "+ex);
	        ex.printStackTrace();
		}
		return res;
	}
	
	
	
	
	public JSONArray getSchedules(JSONObject req)
	{
		JSONArray res=new JSONArray();
		try
		{
			int busId=(int)req.get("busId");
			return scheduleDAO.getSchedules(busId);
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while getting Schedules "+ex);
	        ex.printStackTrace();
		}
		return res;
		
	}
	public JSONObject cancelSchedule(JSONObject req)
	{
		JSONObject res=new JSONObject();
		try
		{
			int scheduleId=(int)((long)req.get("scheduleId"));
    		int ownerId=(int)((long)req.get("ownerId"));
			scheduleDAO.cancelSchedule(scheduleId,ownerId);
			res.put("status",Message.TRIP_CANCELLED);
			 res.put("success",Message.TRIP_CANCELLED);
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while getting Schedules "+ex);
	        ex.printStackTrace();
		}
		return res;
		
	}

}
