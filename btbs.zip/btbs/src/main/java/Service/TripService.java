package Service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import DAO.DAOProvider;
import DAO.SeatingDAO;
import DAO.TripDAO;
import Utils.Message;

public class TripService extends Service {
	TripDAO tripDAO=(TripDAO)DAOProvider.getInstance("TripDAO");
	SeatingDAO seatingDAO=(SeatingDAO)DAOProvider.getInstance("SeatingDAO");
	public JSONArray getTrips(JSONObject req)
	{
		JSONArray res=new JSONArray();
		try
		{
			int busId=(int)req.get("busId");
			int userId=(int)req.get("userId");
			int userRoleId=(int)req.get("userRoleId");
			return tripDAO.getTrips(busId,userId,userRoleId);
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while getting Schedules "+ex);
	        ex.printStackTrace();
		}
		return res;
		
	}
	public JSONObject cancelTrip(JSONObject req)
	{
		JSONObject res=new JSONObject();
		try
		{
			int tripId=(int)((long)req.get("tripId"));
    		int ownerId=(int)((long)req.get("ownerId"));
			tripDAO.cancelTrip(tripId,ownerId);
			res.put("status",Message.TRIP_CANCELLED);
			 res.put("success",Message.TRIP_CANCELLED);
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while getting Schedules "+ex);
	        ex.printStackTrace();
		}
		return res;
		
	}
	
	
	
	public JSONArray getAvailableSeats(JSONObject req)
	{
		JSONArray res=new JSONArray();
		try
		{
			return seatingDAO.getAvailableSeats(req);
		}
		catch(Exception ex)
		{
	        System.out.println("Exception occured while getting Schedules "+ex);
	        ex.printStackTrace();
		}
		return res;
	}

}
